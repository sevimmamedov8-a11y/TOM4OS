extends Button
## Карточка одной игры в сетке. Корневой узел - Button (не обычный Control!),
## чтобы карточка сама умела принимать фокус и обрабатывать "нажатие"
## геймпадом. Клик/нажатие открывает экран игры (GameDetail), а не запускает
## игру напрямую.

signal open_requested(game_id: String)
signal menu_requested(game_id: String)

@onready var cover_rect: TextureRect = $VBox/CoverRect
@onready var name_label: Label = $VBox/NameLabel
@onready var playtime_label: Label = $VBox/PlaytimeLabel
@onready var playing_badge: Label = $VBox/PlayingBadge
@onready var favorite_badge: Label = $VBox/CoverRect/FavoriteBadge

var game_id: String = ""
var _base_playtime: int = 0


func setup(game: Dictionary) -> void:
	game_id = game["id"]
	name_label.text = game["name"]
	_base_playtime = int(game.get("playtime_seconds", 0))
	playtime_label.text = GameLibrary.format_playtime(_base_playtime)
	favorite_badge.visible = bool(game.get("favorite", false))

	var is_running := false
	for info in GameLibrary.running_processes.values():
		if info["id"] == game_id:
			is_running = true
			break
	playing_badge.visible = is_running

	var cover_path: String = game.get("cover_path", "")
	if not cover_path.is_empty() and FileAccess.file_exists(cover_path):
		var img := Image.new()
		var err := img.load(cover_path)
		if err == OK:
			cover_rect.texture = ImageTexture.create_from_image(img)


func get_game_id() -> String:
	return game_id


func set_favorite(is_favorite: bool) -> void:
	favorite_badge.visible = is_favorite


func update_live_playtime(session_seconds: int) -> void:
	playtime_label.text = GameLibrary.format_playtime(_base_playtime + session_seconds)
	playing_badge.visible = true


# Виртуальный метод BaseButton - вызывается по нажатию мышью/пробелом/Enter/
# кнопкой подтверждения на геймпаде (ui_accept: A на Xbox / X на других геймпадах)
func _pressed() -> void:
	open_requested.emit(game_id)


func _gui_input(event: InputEvent) -> void:
	# Обрабатываем только открытие меню карточки; всё остальное (клик мышью,
	# Enter, кнопка подтверждения на геймпаде) не трогаем - эти события не
	# нужно "поглощать", они и так долетают до стандартной обработки Button
	# (accept_event() вызывается только для интересующего нас события).
	if event.is_action_pressed("open_menu"):
		accept_event()
		menu_requested.emit(game_id)


func _ready() -> void:
	focus_entered.connect(func() -> void:
		_animate(1.06)
		SettingsData.vibrate(0.15, 0.05, 0.06)
	)
	focus_exited.connect(func() -> void: _animate(1.0))
	mouse_entered.connect(func() -> void: _animate(1.06))
	mouse_exited.connect(func() -> void:
		if not has_focus():
			_animate(1.0)
	)


func _animate(target: float) -> void:
	pivot_offset = size / 2.0
	if not SettingsData.get_animations_enabled():
		scale = Vector2(target, target)
		return
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector2(target, target), 0.12).set_trans(Tween.TRANS_SINE)
