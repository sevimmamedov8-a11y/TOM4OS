extends Control
## Экран настроек: слева список разделов, справа их
## содержимое. Все изменения применяются сразу и сохраняются.

@onready var sidebar: VBoxContainer = $Dim/CenterContainer/Panel/HBox/Sidebar

@onready var page_appearance: Control = $Dim/CenterContainer/Panel/HBox/Pages/Appearance
@onready var page_library: Control = $Dim/CenterContainer/Panel/HBox/Pages/Library
@onready var page_users: Control = $Dim/CenterContainer/Panel/HBox/Pages/Users
@onready var page_achievements: Control = $Dim/CenterContainer/Panel/HBox/Pages/Achievements
@onready var page_about: Control = $Dim/CenterContainer/Panel/HBox/Pages/About

@onready var columns_spin: SpinBox = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/ColumnsRow/ColumnsSpin
@onready var animations_check: CheckButton = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/AnimationsCheck
@onready var vibration_check: CheckButton = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/VibrationCheck
@onready var music_check: CheckButton = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/MusicCheck
@onready var music_volume_slider: HSlider = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/MusicVolumeRow/MusicVolumeSlider
@onready var background_option: OptionButton = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/BackgroundRow/BackgroundOption
@onready var language_option: OptionButton = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/LanguageRow/LanguageOption
@onready var accent_swatches: HBoxContainer = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/AccentRow/AccentSwatches

@onready var auto_icon_check: CheckButton = $Dim/CenterContainer/Panel/HBox/Pages/Library/VBox/AutoIconCheck
@onready var api_key_edit: LineEdit = $Dim/CenterContainer/Panel/HBox/Pages/Library/VBox/ApiKeyEdit
@onready var refresh_covers_status: Label = $Dim/CenterContainer/Panel/HBox/Pages/Library/VBox/RefreshStatus

@onready var users_list: VBoxContainer = $Dim/CenterContainer/Panel/HBox/Pages/Users/VBox/UsersList
@onready var achievements_list: VBoxContainer = $Dim/CenterContainer/Panel/HBox/Pages/Achievements/VBox/ScrollContainer/AchievementsList
@onready var controller_hints := $Dim/CenterContainer/Panel/HBox/Sidebar/HintsRow/ControllerHints

const ACCENT_COLORS: Array[String] = [
	"#4f9dde", "#e5636b", "#59c48a", "#caa23e",
	"#9b6fd1", "#3fb8c9", "#e8935a", "#7fd1c9",
]
const CreateUserDialogScene := preload("res://scenes/CreateUserDialog.tscn")
const AvatarScene := preload("res://scenes/AvatarView.tscn")

var _sidebar_buttons: Array = []
var _all_pages: Array = []


func _ready() -> void:
	_sidebar_buttons = [
		sidebar.get_node("BtnAppearance"),
		sidebar.get_node("BtnLibrary"),
		sidebar.get_node("BtnUsers"),
		sidebar.get_node("BtnAchievements"),
		sidebar.get_node("BtnAbout"),
	]
	_all_pages = [page_appearance, page_library, page_users, page_achievements, page_about]

	controller_hints.set_hints([
		{"kind": 1, "keyboard": "ESC", "text": "Закрыть"},
	])

	for i in _sidebar_buttons.size():
		var idx := i
		_sidebar_buttons[i].pressed.connect(func() -> void: _show_page(idx))

	# --- Внешний вид ---
	language_option.clear()
	for i in SettingsData.AVAILABLE_LANGUAGES.size():
		var lang: Dictionary = SettingsData.AVAILABLE_LANGUAGES[i]
		language_option.add_item(lang["name"], i)
	var current_lang := SettingsData.get_language()
	for i in SettingsData.AVAILABLE_LANGUAGES.size():
		if SettingsData.AVAILABLE_LANGUAGES[i]["code"] == current_lang:
			language_option.select(i)
			break
	language_option.item_selected.connect(_on_language_selected)

	columns_spin.value = SettingsData.get_columns()
	columns_spin.value_changed.connect(func(v: float) -> void: SettingsData.set_columns(int(v)))

	animations_check.button_pressed = SettingsData.get_animations_enabled()
	animations_check.toggled.connect(func(v: bool) -> void: SettingsData.set_animations_enabled(v))

	vibration_check.button_pressed = SettingsData.get_vibration_enabled()
	vibration_check.toggled.connect(func(v: bool) -> void: SettingsData.set_vibration_enabled(v))

	music_check.button_pressed = SettingsData.get_music_enabled()
	music_check.toggled.connect(func(v: bool) -> void: SettingsData.set_music_enabled(v))

	music_volume_slider.value = SettingsData.get_music_volume()
	music_volume_slider.value_changed.connect(func(v: float) -> void: SettingsData.set_music_volume(v))

	background_option.clear()
	background_option.add_item("Обложка последней игры (размыто)", 0)
	background_option.add_item("Градиент", 1)
	background_option.add_item("Сплошной цвет", 2)
	background_option.add_item("Живой фон (плавные цветные волны)", 3)
	var style := SettingsData.get_background_style()
	background_option.select(_style_to_index(style))
	background_option.item_selected.connect(_on_background_selected)

	for hex: String in ACCENT_COLORS:
		var b := Button.new()
		b.custom_minimum_size = Vector2(34, 34)
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(hex)
		sb.corner_radius_top_left = 8
		sb.corner_radius_top_right = 8
		sb.corner_radius_bottom_left = 8
		sb.corner_radius_bottom_right = 8
		b.add_theme_stylebox_override("normal", sb)
		b.add_theme_stylebox_override("hover", sb)
		b.add_theme_stylebox_override("pressed", sb)
		b.add_theme_stylebox_override("focus", sb)
		var hex_captured: String = hex
		b.pressed.connect(func() -> void: SettingsData.set_accent_color(hex_captured))
		accent_swatches.add_child(b)

	# --- Игры и обложки ---
	auto_icon_check.button_pressed = SettingsData.get_auto_icon_enabled()
	auto_icon_check.toggled.connect(func(v: bool) -> void: SettingsData.set_auto_icon_enabled(v))
	api_key_edit.text = SettingsData.get_steamgriddb_key()

	# --- Пользователи ---
	UserManager.users_changed.connect(_refresh_users_list)
	_refresh_users_list()

	# --- Достижения ---
	GameLibrary.achievement_unlocked.connect(func(_id: String, _title: String) -> void: _refresh_achievements_list())
	_refresh_achievements_list()

	_show_page(0)


func _show_page(idx: int) -> void:
	for i in _all_pages.size():
		_all_pages[i].visible = (i == idx)
	for i in _sidebar_buttons.size():
		_sidebar_buttons[i].button_pressed = (i == idx)


func _style_to_index(style: String) -> int:
	match style:
		"gradient":
			return 1
		"solid":
			return 2
		"animated":
			return 3
		_:
			return 0


func _on_background_selected(idx: int) -> void:
	var style := "cover"
	match idx:
		1:
			style = "gradient"
		2:
			style = "solid"
		3:
			style = "animated"
	SettingsData.set_background_style(style)


func _on_language_selected(idx: int) -> void:
	if idx < 0 or idx >= SettingsData.AVAILABLE_LANGUAGES.size():
		return
	SettingsData.set_language(SettingsData.AVAILABLE_LANGUAGES[idx]["code"])


func _on_save_api_key_pressed() -> void:
	SettingsData.set_steamgriddb_key(api_key_edit.text)


func _on_refresh_covers_pressed() -> void:
	if GameLibrary.games.is_empty():
		refresh_covers_status.text = "В библиотеке пока нет игр."
		return
	refresh_covers_status.text = "Обновляю обложки..."
	var updated := 0
	for g in GameLibrary.games:
		if SettingsData.get_auto_icon_enabled():
			if GameLibrary.auto_set_cover_from_exe(g["id"]):
				updated += 1
	refresh_covers_status.text = tr("Готово: обновлено %d из %d") % [updated, GameLibrary.games.size()]


func _refresh_users_list() -> void:
	for c in users_list.get_children():
		c.queue_free()
	for u in UserManager.users:
		users_list.add_child(_make_user_row(u))


func _make_user_row(u: Dictionary) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)

	var avatar := AvatarScene.instantiate()
	avatar.custom_minimum_size = Vector2(48, 48)
	row.add_child(avatar)
	avatar.setup(u.get("name", ""), u.get("accent_color", "#4f9dde"), u.get("avatar_path", ""))

	var name_label := Label.new()
	name_label.text = u.get("name", "")
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(name_label)

	if u["id"] == UserManager.current_user_id:
		var current_tag := Label.new()
		current_tag.text = "(текущий)"
		current_tag.modulate = Color(0.6, 0.9, 0.6, 1)
		row.add_child(current_tag)

	var user_id: String = u["id"]

	var edit_btn := Button.new()
	edit_btn.text = "Изменить"
	edit_btn.pressed.connect(func() -> void: _on_edit_user_pressed(user_id))
	row.add_child(edit_btn)

	if u["id"] != UserManager.current_user_id:
		var del_btn := Button.new()
		del_btn.text = "Удалить"
		del_btn.pressed.connect(func() -> void: UserManager.delete_user(user_id))
		row.add_child(del_btn)

	return row


func _on_edit_user_pressed(user_id: String) -> void:
	var dlg := CreateUserDialogScene.instantiate()
	add_child(dlg)
	dlg.setup_for_edit(user_id)
	dlg.popup_centered()


func _on_add_user_pressed() -> void:
	var dlg := CreateUserDialogScene.instantiate()
	add_child(dlg)
	dlg.popup_centered()


func _refresh_achievements_list() -> void:
	for c in achievements_list.get_children():
		c.queue_free()
	for def in GameLibrary.ACHIEVEMENTS:
		achievements_list.add_child(_make_achievement_row(def))


func _make_achievement_row(def: Dictionary) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)

	var unlocked: bool = GameLibrary.unlocked_achievements.has(def["id"])

	var icon := Label.new()
	icon.text = "🏆"
	icon.add_theme_font_size_override("font_size", 28)
	icon.modulate = Color(1, 0.85, 0.3, 1) if unlocked else Color(0.35, 0.37, 0.4, 1)
	row.add_child(icon)

	var vb := VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(vb)

	var title_lbl := Label.new()
	title_lbl.text = def.get("title", "")
	title_lbl.modulate = Color(1, 1, 1, 1) if unlocked else Color(0.6, 0.63, 0.67, 1)
	vb.add_child(title_lbl)

	var desc_lbl := Label.new()
	desc_lbl.text = def.get("desc", "")
	desc_lbl.add_theme_font_size_override("font_size", 12)
	desc_lbl.modulate = Color(0.7, 0.75, 0.8, 1)
	vb.add_child(desc_lbl)

	if unlocked:
		var tag := Label.new()
		tag.text = "Получено"
		tag.modulate = Color(0.5, 0.9, 0.55, 1)
		row.add_child(tag)

	return row


func _on_switch_user_pressed() -> void:
	queue_free()
	Transitions.fade_to_scene("res://scenes/ProfileSelect.tscn")


func _on_close_pressed() -> void:
	queue_free()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		queue_free()
