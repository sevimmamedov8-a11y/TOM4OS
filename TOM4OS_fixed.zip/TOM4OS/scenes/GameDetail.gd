extends Control
## Экран отдельной игры: открывается по клику на карточку. Большая обложка,
## название, наигранное время и кнопка "Играть". Явно показывает, что
## счётчик времени останавливается сразу после закрытия игры.

signal rename_requested(game_id: String)
signal cover_requested(game_id: String)
signal delete_requested(game_id: String)

@onready var panel: PanelContainer = $CenterContainer/Panel
@onready var cover_rect: TextureRect = $CenterContainer/Panel/VBox/CoverRect
@onready var title_label: Label = $CenterContainer/Panel/VBox/TitleLabel
@onready var playtime_label: Label = $CenterContainer/Panel/VBox/PlaytimeLabel
@onready var status_label: Label = $CenterContainer/Panel/VBox/StatusLabel
@onready var play_button: Button = $CenterContainer/Panel/VBox/PlayButton
@onready var favorite_button: Button = $CenterContainer/Panel/VBox/ActionsRow/FavoriteButton
@onready var controller_hints := $CenterContainer/Panel/VBox/HintsRow/ControllerHints

var game_id: String = ""
var _base_playtime: int = 0
var _is_running: bool = false


func setup(id: String) -> void:
	game_id = id
	_refresh()

	controller_hints.set_hints([
		{"kind": 0, "keyboard": "ENTER", "text": "Играть"},
		{"kind": 1, "keyboard": "ESC", "text": "Назад"},
	])

	GameLibrary.library_changed.connect(_on_library_changed)
	GameLibrary.playtime_tick.connect(_on_tick)
	GameLibrary.game_started.connect(_on_started)
	GameLibrary.game_stopped.connect(_on_stopped)

	modulate.a = 0.0
	panel.scale = Vector2(0.92, 0.92)
	panel.pivot_offset = panel.size / 2.0

	if SettingsData.get_animations_enabled():
		var tw := create_tween()
		tw.set_parallel(true)
		tw.tween_property(self, "modulate:a", 1.0, 0.22)
		tw.tween_property(panel, "scale", Vector2(1.0, 1.0), 0.22).set_trans(Tween.TRANS_BACK)
	else:
		modulate.a = 1.0
		panel.scale = Vector2(1.0, 1.0)


func _refresh() -> void:
	var g := GameLibrary.get_game(game_id)
	if g.is_empty():
		return

	title_label.text = g.get("name", "")
	_base_playtime = int(g.get("playtime_seconds", 0))
	playtime_label.text = tr("Наиграно: %s") % GameLibrary.format_playtime(_base_playtime)

	_is_running = false
	for info in GameLibrary.running_processes.values():
		if info["id"] == game_id:
			_is_running = true
			break
	_update_play_button()

	var cover_path: String = g.get("cover_path", "")
	if not cover_path.is_empty() and FileAccess.file_exists(cover_path):
		var img := Image.new()
		if img.load(cover_path) == OK:
			cover_rect.texture = ImageTexture.create_from_image(img)

	if bool(g.get("favorite", false)):
		favorite_button.text = "★ В избранном"
	else:
		favorite_button.text = "☆ В избранное"


func _update_play_button() -> void:
	if _is_running:
		play_button.text = "Игра запущена..."
		play_button.disabled = true
		status_label.text = "Счётчик времени считается, пока игра открыта"
	else:
		play_button.text = "▶ Играть"
		play_button.disabled = false


func _on_library_changed() -> void:
	if not GameLibrary.get_game(game_id).is_empty():
		_refresh()


func _on_tick(id: String, session_seconds: int) -> void:
	if id != game_id:
		return
	playtime_label.text = tr("Наиграно: %s") % GameLibrary.format_playtime(_base_playtime + session_seconds)


func _on_started(id: String) -> void:
	if id != game_id:
		return
	_is_running = true
	_update_play_button()


func _on_stopped(id: String, _session_seconds: int) -> void:
	if id != game_id:
		return
	_is_running = false
	# Игра закрыта: GameLibrary уже сохранил финальное время сессии,
	# счётчик здесь останавливается и больше не тикает.
	_update_play_button()
	status_label.text = "Игра закрыта. Время сохранено, счётчик остановлен."


func _on_play_pressed() -> void:
	SettingsData.vibrate(0.4, 0.7, 0.15)
	GameLibrary.launch_game(game_id)


func _on_rename_pressed() -> void:
	rename_requested.emit(game_id)


func _on_favorite_pressed() -> void:
	GameLibrary.toggle_favorite(game_id)


func _on_cover_pressed() -> void:
	cover_requested.emit(game_id)


func _on_delete_pressed() -> void:
	delete_requested.emit(game_id)
	_close()


func _on_back_pressed() -> void:
	_close()


func _close() -> void:
	if GameLibrary.library_changed.is_connected(_on_library_changed):
		GameLibrary.library_changed.disconnect(_on_library_changed)
	if GameLibrary.playtime_tick.is_connected(_on_tick):
		GameLibrary.playtime_tick.disconnect(_on_tick)
	if GameLibrary.game_started.is_connected(_on_started):
		GameLibrary.game_started.disconnect(_on_started)
	if GameLibrary.game_stopped.is_connected(_on_stopped):
		GameLibrary.game_stopped.disconnect(_on_stopped)

	if SettingsData.get_animations_enabled():
		var tw := create_tween()
		tw.tween_property(self, "modulate:a", 0.0, 0.15)
		await tw.finished
	queue_free()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		_close()
