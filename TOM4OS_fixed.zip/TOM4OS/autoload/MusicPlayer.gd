extends Node
## Autoload-синглтон. Проигрывает спокойную фоновую музыку по кругу
## на всех экранах лаунчера (Boot, ProfileSelect, Main, Settings...),
## поскольку сам является persist-синглтоном и не уничтожается при
## смене сцен. Громкость и вкл/выкл берутся из SettingsData и применяются
## сразу, как только меняются в Настройках.

const TRACK_PATH := "res://audio/background_loop.ogg"

var _player: AudioStreamPlayer


func _ready() -> void:
	_player = AudioStreamPlayer.new()
	_player.name = "MusicStreamPlayer"
	_player.bus = "Master"
	add_child(_player)

	var stream: AudioStream = load(TRACK_PATH)
	if stream == null:
		push_warning("MusicPlayer: не удалось загрузить %s" % TRACK_PATH)
		return

	# Включаем зацикливание прямо в коде, чтобы не зависеть от настроек
	# импорта ресурса в редакторе — так гарантированно работает всегда.
	if stream is AudioStreamOggVorbis:
		stream.loop = true
	elif stream is AudioStreamWAV:
		stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	elif stream is AudioStreamMP3:
		stream.loop = true

	_player.stream = stream
	_apply_volume()

	SettingsData.settings_changed.connect(_apply_volume)

	if SettingsData.get_music_enabled():
		_player.play()


func _apply_volume() -> void:
	if _player == null:
		return

	var enabled := SettingsData.get_music_enabled()
	var volume: float = SettingsData.get_music_volume()

	if not enabled:
		if _player.playing:
			_player.stop()
		return

	_player.volume_db = linear_to_db(clampf(volume, 0.001, 1.0))
	if not _player.playing:
		_player.play()
