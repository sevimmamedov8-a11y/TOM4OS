extends Node
## Autoload-синглтон. Хранит список игр ТЕКУЩЕГО пользователя, сохраняет их
## в JSON внутри персональной папки этого пользователя, запускает игры,
## отслеживает наигранное время, умеет автоматически доставать иконку
## из .exe в качестве обложки, а также ведёт избранное и достижения профиля.

signal library_changed
signal game_started(game_id: String)
signal game_stopped(game_id: String, session_seconds: int)
signal playtime_tick(game_id: String, session_seconds: int)
signal achievement_unlocked(id: String, title: String)

## Фиксированный список достижений. Условия проверяются в _check_achievements().
const ACHIEVEMENTS: Array[Dictionary] = [
	{"id": "first_game", "title": "Первая игра", "desc": "Добавь свою первую игру в библиотеку"},
	{"id": "collector_5", "title": "Коллекционер", "desc": "Добавь 5 игр в библиотеку"},
	{"id": "collector_10", "title": "Растущая библиотека", "desc": "Добавь 10 игр в библиотеку"},
	{"id": "first_session", "title": "Первая сессия", "desc": "Заверши хотя бы одну игровую сессию"},
	{"id": "played_10", "title": "Исследователь", "desc": "Запусти хотя бы раз 10 разных игр"},
	{"id": "hour_1", "title": "Втянулся", "desc": "Наиграй суммарно 1 час"},
	{"id": "hour_10", "title": "Марафонец", "desc": "Наиграй суммарно 10 часов"},
	{"id": "hour_50", "title": "Опытный игрок", "desc": "Наиграй суммарно 50 часов"},
	{"id": "hour_100", "title": "Ветеран", "desc": "Наиграй суммарно 100 часов"},
	{"id": "warrior_500", "title": "Кто ты воин?", "desc": "Наиграй суммарно 500 часов"},
	{"id": "loyal_fan", "title": "Верный фанат", "desc": "Наиграй 20 часов в одну игру"},
	{"id": "favorite_1", "title": "Любимая игра", "desc": "Добавь игру в избранное"},
	{"id": "favorite_5", "title": "Список фаворитов", "desc": "Добавь 5 игр в избранное"},
]

var games: Array = []                     # Array[Dictionary]
var running_processes: Dictionary = {}    # pid(int) -> {id: String, start_time: float}
var unlocked_achievements: Array = []     # Array[String] - id достижений текущего профиля

var _save_path: String = ""
var _covers_dir: String = ""
var _achievements_path: String = ""
var _poll_timer: Timer


func _ready() -> void:
	_setup_input_actions()

	_poll_timer = Timer.new()
	_poll_timer.wait_time = 1.0
	_poll_timer.autostart = true
	_poll_timer.timeout.connect(_on_poll_timeout)
	add_child(_poll_timer)


func _setup_input_actions() -> void:
	if not InputMap.has_action("open_menu"):
		InputMap.add_action("open_menu")

		var joy_event := InputEventJoypadButton.new()
		joy_event.button_index = JOY_BUTTON_Y  # Y на Xbox-геймпаде / Треугольник на других геймпадах
		InputMap.action_add_event("open_menu", joy_event)

		var key_event := InputEventKey.new()
		key_event.keycode = KEY_F1  # запасной вариант для клавиатуры
		InputMap.action_add_event("open_menu", key_event)

	if not InputMap.has_action("toggle_favorite"):
		InputMap.add_action("toggle_favorite")

		var fav_joy := InputEventJoypadButton.new()
		fav_joy.button_index = JOY_BUTTON_X  # Квадрат на PlayStation / X на Xbox-геймпаде
		InputMap.action_add_event("toggle_favorite", fav_joy)

		var fav_key := InputEventKey.new()
		fav_key.keycode = KEY_F  # запасной вариант для клавиатуры
		InputMap.action_add_event("toggle_favorite", fav_key)

	# ВАЖНО: у встроенных действий ui_accept/ui_cancel по умолчанию есть
	# только клавиатурные события (Enter/Space и Escape) - события с
	# геймпада для них нужно добавлять руками, иначе кнопки подтверждения
	# и отмены (Cross/Circle на PlayStation, A/B на Xbox) не будут
	# реагировать на геймпаде, хотя в коде на них рассчитывают (см.
	# комментарии в GameCard.gd и обработку ui_cancel в Main.gd).
	_ensure_joypad_event("ui_accept", JOY_BUTTON_A)
	_ensure_joypad_event("ui_cancel", JOY_BUTTON_B)


func _ensure_joypad_event(action: String, button_index: int) -> void:
	for event in InputMap.action_get_events(action):
		if event is InputEventJoypadButton and event.button_index == button_index:
			return  # уже добавлено раньше - не дублируем

	var joy_event := InputEventJoypadButton.new()
	joy_event.button_index = button_index
	InputMap.action_add_event(action, joy_event)


# ---------- Переключение библиотеки при смене пользователя ----------

func reload_for_current_user() -> void:
	var uid := UserManager.current_user_id
	if uid.is_empty():
		_save_path = "user://games.json"
		_covers_dir = "user://covers/"
		_achievements_path = "user://achievements.json"
	else:
		_save_path = "user://users/%s/games.json" % uid
		_covers_dir = "user://users/%s/covers/" % uid
		_achievements_path = "user://users/%s/achievements.json" % uid

	running_processes.clear()
	_ensure_covers_dir()
	load_games()
	_load_achievements()
	_check_achievements()


func get_covers_dir() -> String:
	return _covers_dir


func _ensure_covers_dir() -> void:
	if not _covers_dir.is_empty() and not DirAccess.dir_exists_absolute(_covers_dir):
		DirAccess.make_dir_recursive_absolute(_covers_dir)


func _generate_id() -> String:
	return str(int(Time.get_unix_time_from_system())) + "_" + str(randi() % 1000000)


# ---------- Сохранение / загрузка ----------

func load_games() -> void:
	games.clear()

	if _save_path.is_empty() or not FileAccess.file_exists(_save_path):
		save_games()
		library_changed.emit()
		return

	var file := FileAccess.open(_save_path, FileAccess.READ)
	if file == null:
		push_error("GameLibrary: не удалось открыть файл сохранения, код ошибки: %s" % FileAccess.get_open_error())
		library_changed.emit()
		return

	var text := file.get_as_text()
	file.close()

	var parsed = JSON.parse_string(text)
	if typeof(parsed) == TYPE_DICTIONARY and parsed.has("games"):
		games = parsed["games"]

	library_changed.emit()


func save_games() -> void:
	if _save_path.is_empty():
		return
	var data := {"games": games}
	var file := FileAccess.open(_save_path, FileAccess.WRITE)
	if file == null:
		push_error("GameLibrary: не удалось записать файл сохранения, код ошибки: %s" % FileAccess.get_open_error())
		return
	file.store_string(JSON.stringify(data, "\t"))
	file.close()


# ---------- CRUD для игр ----------

func add_game(exe_path: String, display_name: String = "") -> Dictionary:
	var final_name := display_name
	if final_name.is_empty():
		final_name = exe_path.get_file().get_basename()

	var entry := {
		"id": _generate_id(),
		"name": final_name,
		"exe_path": exe_path,
		"args": "",
		"cover_path": "",
		"playtime_seconds": 0,
		"last_played": "",
		"favorite": false,
	}
	games.append(entry)
	save_games()
	library_changed.emit()
	_check_achievements()
	return entry


func remove_game(game_id: String) -> void:
	for i in games.size():
		if games[i]["id"] == game_id:
			games.remove_at(i)
			break
	save_games()
	library_changed.emit()


func rename_game(game_id: String, new_name: String) -> void:
	var g := get_game(game_id)
	if not g.is_empty() and not new_name.strip_edges().is_empty():
		g["name"] = new_name.strip_edges()
		save_games()
		library_changed.emit()


func set_cover(game_id: String, texture_path: String) -> void:
	var g := get_game(game_id)
	if not g.is_empty():
		g["cover_path"] = texture_path
		save_games()
		library_changed.emit()


func toggle_favorite(game_id: String) -> void:
	var g := get_game(game_id)
	if g.is_empty():
		return
	g["favorite"] = not bool(g.get("favorite", false))
	save_games()
	library_changed.emit()
	_check_achievements()


func get_game(game_id: String) -> Dictionary:
	for g in games:
		if g["id"] == game_id:
			return g
	return {}


# ---------- Запуск игр и учёт времени ----------

func launch_game(game_id: String) -> void:
	var g := get_game(game_id)
	if g.is_empty():
		push_error("GameLibrary: игра с id '%s' не найдена" % game_id)
		return

	if not FileAccess.file_exists(g["exe_path"]):
		push_error("GameLibrary: exe не найден по пути: %s" % g["exe_path"])
		return

	var arg_list: PackedStringArray = []
	if not String(g["args"]).is_empty():
		arg_list = g["args"].split(" ", false)

	var pid := OS.create_process(g["exe_path"], arg_list, false)
	if pid <= 0:
		push_error("GameLibrary: не удалось запустить %s" % g["exe_path"])
		return

	running_processes[pid] = {
		"id": game_id,
		"start_time": Time.get_unix_time_from_system(),
	}
	game_started.emit(game_id)


func _on_poll_timeout() -> void:
	var finished_pids: Array = []

	for pid in running_processes.keys():
		if not OS.is_process_running(pid):
			finished_pids.append(pid)
		else:
			var info: Dictionary = running_processes[pid]
			var elapsed := int(Time.get_unix_time_from_system() - info["start_time"])
			playtime_tick.emit(info["id"], elapsed)

	# Как только процесс игры больше не существует, счётчик времени
	# останавливается: сессия фиксируется один раз и прибавляется к общему
	# наигранному времени, дальнейшие playtime_tick для этой игры не идут.
	for pid in finished_pids:
		var info: Dictionary = running_processes[pid]
		var session_seconds := int(Time.get_unix_time_from_system() - info["start_time"])
		var g := get_game(info["id"])
		if not g.is_empty():
			g["playtime_seconds"] = int(g.get("playtime_seconds", 0)) + session_seconds
			g["last_played"] = Time.get_datetime_string_from_system()
			save_games()
		running_processes.erase(pid)
		game_stopped.emit(info["id"], session_seconds)
		library_changed.emit()
		_check_achievements()


func format_playtime(seconds: int) -> String:
	if seconds < 60:
		return tr("%d сек") % seconds
	elif seconds < 3600:
		return tr("%d мин") % (seconds / 60)
	else:
		return tr("%.1f ч") % (seconds / 3600.0)


# ---------- Автообложка: берём иконку прямо из .exe (Windows) ----------
# Использует System.Drawing через PowerShell (есть в любой Windows из коробки,
# ничего дополнительно ставить не нужно).

func extract_exe_icon(exe_path: String, out_path: String) -> bool:
	if OS.get_name() != "Windows":
		return false
	if not FileAccess.file_exists(exe_path):
		return false

	var abs_exe := exe_path
	if abs_exe.begins_with("res://") or abs_exe.begins_with("user://"):
		abs_exe = ProjectSettings.globalize_path(abs_exe)

	var abs_out := out_path
	if abs_out.begins_with("res://") or abs_out.begins_with("user://"):
		abs_out = ProjectSettings.globalize_path(abs_out)

	# В PowerShell-строках с одинарными кавычками экранируем ' как ''.
	var ps_exe := abs_exe.replace("'", "''")
	var ps_out := abs_out.replace("'", "''")

	var ps_script := (
		"Add-Type -AssemblyName System.Drawing; " +
		"try { " +
		("$ic = [System.Drawing.Icon]::ExtractAssociatedIcon('%s'); " % ps_exe) +
		"if ($ic -ne $null) { " +
		"$bmp = $ic.ToBitmap(); " +
		("$bmp.Save('%s', [System.Drawing.Imaging.ImageFormat]::Png); " % ps_out) +
		"$bmp.Dispose(); $ic.Dispose(); " +
		"} } catch { exit 1 }"
	)

	# Команда кодируется в Base64 (UTF-16LE) и передаётся через -EncodedCommand.
	# Раньше путь к .exe вставлялся прямо в командную строку в двойных
	# кавычках - Windows иногда ломает такую строку на отдельные аргументы
	# (особенно если в пути есть пробелы или свои кавычки), и PowerShell
	# получал обрезанный путь, из-за чего иконка тихо не извлекалась.
	# -EncodedCommand передаётся одним argument без пробелов и кавычек,
	# так что путь до .exe долетает всегда одним куском.
	var utf16_bytes := ps_script.to_utf16_buffer()
	var encoded_command := Marshalls.raw_to_base64(utf16_bytes)

	var args := PackedStringArray([
		"-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden",
		"-EncodedCommand", encoded_command,
	])
	var output := []
	var exit_code := OS.execute("powershell.exe", args, output, true, false)

	if exit_code != 0:
		push_warning("GameLibrary: извлечение иконки завершилось с кодом %d. Вывод: %s" % [exit_code, output])

	return exit_code == 0 and FileAccess.file_exists(out_path)


func auto_set_cover_from_exe(game_id: String) -> bool:
	var g := get_game(game_id)
	if g.is_empty():
		return false
	_ensure_covers_dir()
	var out_path := "%s%s_icon.png" % [_covers_dir, game_id]
	if extract_exe_icon(g["exe_path"], out_path):
		set_cover(game_id, out_path)
		return true
	return false


# ---------- Автопоиск обложки через SteamGridDB (резервный вариант) ----------
# Требует бесплатный API-ключ: https://www.steamgriddb.com/profile/preferences/api

func fetch_cover_from_steamgriddb(game_id: String, api_key: String) -> void:
	var game := get_game(game_id)
	if game.is_empty():
		return
	if api_key.is_empty():
		push_error("GameLibrary: не задан API-ключ SteamGridDB")
		return

	_ensure_covers_dir()

	var headers := ["Authorization: Bearer %s" % api_key]
	var query := String(game["name"]).uri_encode()

	# Шаг 1: найти игру по названию
	var search_req := HTTPRequest.new()
	add_child(search_req)
	search_req.request("https://www.steamgriddb.com/api/v2/search/autocomplete/%s" % query, headers)
	var search_result = await search_req.request_completed
	search_req.queue_free()

	var search_code: int = search_result[1]
	var search_body: PackedByteArray = search_result[3]
	if search_code != 200:
		push_error("SteamGridDB: ошибка поиска, код %d" % search_code)
		return

	var search_data = JSON.parse_string(search_body.get_string_from_utf8())
	if search_data == null or not search_data.get("success", false):
		push_error("SteamGridDB: поиск не удался")
		return

	var results: Array = search_data.get("data", [])
	if results.is_empty():
		push_error("SteamGridDB: ничего не найдено по запросу '%s'" % game["name"])
		return

	var sgdb_id = results[0]["id"]

	# Шаг 2: получить список обложек для найденной игры
	var grid_req := HTTPRequest.new()
	add_child(grid_req)
	grid_req.request("https://www.steamgriddb.com/api/v2/grids/game/%d" % sgdb_id, headers)
	var grid_result = await grid_req.request_completed
	grid_req.queue_free()

	var grid_code: int = grid_result[1]
	var grid_body: PackedByteArray = grid_result[3]
	if grid_code != 200:
		push_error("SteamGridDB: ошибка загрузки списка обложек, код %d" % grid_code)
		return

	var grid_data = JSON.parse_string(grid_body.get_string_from_utf8())
	var grid_list: Array = grid_data.get("data", [])
	if grid_list.is_empty():
		push_error("SteamGridDB: обложки для '%s' не найдены" % game["name"])
		return

	var image_url: String = grid_list[0]["url"]

	# Шаг 3: скачать саму картинку
	var img_req := HTTPRequest.new()
	add_child(img_req)
	img_req.request(image_url)
	var img_result = await img_req.request_completed
	img_req.queue_free()

	var img_code: int = img_result[1]
	var img_bytes: PackedByteArray = img_result[3]
	if img_code != 200:
		push_error("SteamGridDB: не удалось скачать картинку, код %d" % img_code)
		return

	var ext := image_url.get_extension().to_lower()
	if ext.is_empty():
		ext = "png"

	var save_path := "%s%s.%s" % [_covers_dir, game_id, ext]
	var out_file := FileAccess.open(save_path, FileAccess.WRITE)
	if out_file == null:
		push_error("GameLibrary: не удалось сохранить обложку")
		return
	out_file.store_buffer(img_bytes)
	out_file.close()

	set_cover(game_id, save_path)


# ---------- Достижения профиля ----------

func _load_achievements() -> void:
	unlocked_achievements = []
	if _achievements_path.is_empty() or not FileAccess.file_exists(_achievements_path):
		return

	var file := FileAccess.open(_achievements_path, FileAccess.READ)
	if file == null:
		return
	var text := file.get_as_text()
	file.close()

	var parsed = JSON.parse_string(text)
	if typeof(parsed) == TYPE_DICTIONARY:
		unlocked_achievements = parsed.get("unlocked", [])


func _save_achievements() -> void:
	if _achievements_path.is_empty():
		return
	var file := FileAccess.open(_achievements_path, FileAccess.WRITE)
	if file == null:
		return
	file.store_string(JSON.stringify({"unlocked": unlocked_achievements}, "\t"))
	file.close()


func _find_achievement_def(id: String) -> Dictionary:
	for a in ACHIEVEMENTS:
		if a["id"] == id:
			return a
	return {}


func _unlock_achievement(id: String) -> void:
	if unlocked_achievements.has(id):
		return
	unlocked_achievements.append(id)
	_save_achievements()
	var def := _find_achievement_def(id)
	achievement_unlocked.emit(id, def.get("title", id))


## Проверяет все условия достижений и разблокирует те, что уже выполнены.
## Вызывается после добавления игры, завершения сессии и переключения
## избранного - то есть после любого события, которое могло что-то открыть.
func _check_achievements() -> void:
	var total_playtime := 0
	var favorite_count := 0
	var played_games_count := 0
	var has_played_session := false
	var max_single_game_playtime := 0

	for g in games:
		var seconds := int(g.get("playtime_seconds", 0))
		total_playtime += seconds
		max_single_game_playtime = max(max_single_game_playtime, seconds)
		if bool(g.get("favorite", false)):
			favorite_count += 1
		if not String(g.get("last_played", "")).is_empty():
			has_played_session = true
			played_games_count += 1

	if games.size() >= 1:
		_unlock_achievement("first_game")
	if games.size() >= 5:
		_unlock_achievement("collector_5")
	if games.size() >= 10:
		_unlock_achievement("collector_10")
	if has_played_session:
		_unlock_achievement("first_session")
	if played_games_count >= 10:
		_unlock_achievement("played_10")
	if total_playtime >= 3600:
		_unlock_achievement("hour_1")
	if total_playtime >= 36000:
		_unlock_achievement("hour_10")
	if total_playtime >= 180000:
		_unlock_achievement("hour_50")
	if total_playtime >= 360000:
		_unlock_achievement("hour_100")
	if total_playtime >= 1800000:
		_unlock_achievement("warrior_500")
	if max_single_game_playtime >= 72000:
		_unlock_achievement("loyal_fan")
	if favorite_count >= 1:
		_unlock_achievement("favorite_1")
	if favorite_count >= 5:
		_unlock_achievement("favorite_5")
