extends Control
## Значок одной кнопки контроллера. Автоматически показывает нужный символ:
## A/B/X/Y (Xbox или неизвестный геймпад), ×/○/□/△ (PlayStation) или
## название клавиши (клавиатура) - и сам обновляется при смене типа
## устройства ввода (см. автозагрузку ControllerType).

enum Kind { CONFIRM, CANCEL, MENU, TERTIARY }

@export var kind: Kind = Kind.CONFIRM:
	set(value):
		kind = value
		_refresh()

## Текст, который показывается, если сейчас активна клавиатура (например "ENTER", "ESC", "F1").
@export var keyboard_label: String = "ENTER":
	set(value):
		keyboard_label = value
		_refresh()

@onready var bg: Panel = $Bg
@onready var label: Label = $Bg/Label


func _ready() -> void:
	ControllerType.type_changed.connect(func(_t: int) -> void: _refresh())
	_refresh()


func _refresh() -> void:
	if bg == null or label == null:
		return

	var is_keyboard := ControllerType.current_type == ControllerType.Type.KEYBOARD
	var text: String
	var color: Color

	if is_keyboard:
		text = keyboard_label
		color = Color(0.2, 0.21, 0.25)
	elif ControllerType.current_type == ControllerType.Type.PLAYSTATION:
		match kind:
			Kind.CONFIRM:
				text = "✕"; color = Color("#4f9dde")
			Kind.CANCEL:
				text = "○"; color = Color("#e5636b")
			Kind.MENU:
				text = "△"; color = Color("#59c48a")
			Kind.TERTIARY:
				text = "□"; color = Color("#c96fd1")
	else:
		# Xbox и любой другой геймпад - показываем как Xbox (A/B/X/Y),
		# это общепринятая раскладка для "неизвестных" контроллеров.
		match kind:
			Kind.CONFIRM:
				text = "A"; color = Color("#59c48a")
			Kind.CANCEL:
				text = "B"; color = Color("#e5636b")
			Kind.MENU:
				text = "Y"; color = Color("#caa23e")
			Kind.TERTIARY:
				text = "X"; color = Color("#4f9dde")

	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.shadow_color = Color(0, 0, 0, 0.3)
	sb.shadow_size = 3
	sb.shadow_offset = Vector2(0, 2)

	if is_keyboard:
		sb.set_corner_radius_all(6)
		custom_minimum_size = Vector2(max(32.0, text.length() * 9.0 + 16.0), 26)
	else:
		sb.set_corner_radius_all(15)
		custom_minimum_size = Vector2(28, 28)

	bg.add_theme_stylebox_override("panel", sb)
	label.text = text
	label.add_theme_color_override("font_color", Color.WHITE if not is_keyboard else Color(0.82, 0.85, 0.9))
	label.add_theme_font_size_override("font_size", 15 if not is_keyboard else 12)
