extends Control

@onready var game_grid: GridContainer = $MarginContainer/VBox/ScrollContainer/GameGrid
@onready var clock_label: Label = $MarginContainer/VBox/BottomBar/ClockLabel
@onready var add_game_dialog := $AddGameDialog
@onready var context_menu: PopupMenu = $ContextMenu
@onready var bg_color_rect: ColorRect = $BackgroundLayer/BgColor
@onready var bg_gradient: TextureRect = $BackgroundLayer/BgGradient
@onready var bg_cover: TextureRect = $BackgroundLayer/BgCover
@onready var bg_animated: ColorRect = $BackgroundLayer/BgAnimated
@onready var bg_dim: ColorRect = $BackgroundLayer/Dim
@onready var user_avatar := $MarginContainer/VBox/TopBar/UserBadge/Avatar
@onready var user_name_label: Label = $MarginContainer/VBox/TopBar/UserBadge/NameLabel
@onready var continue_card: PanelContainer = $MarginContainer/VBox/ContinueCard
@onready var continue_cover: TextureRect = $MarginContainer/VBox/ContinueCard/Margin/HBox/Cover
@onready var continue_name_label: Label = $MarginContainer/VBox/ContinueCard/Margin/HBox/Info/NameLabel
@onready var search_edit: LineEdit = $MarginContainer/VBox/LibraryToolbar/SearchEdit
@onready var sort_option: OptionButton = $MarginContainer/VBox/LibraryToolbar/SortOption
@onready var favorites_filter_button: Button = $MarginContainer/VBox/LibraryToolbar/FavoritesFilterButton
@onready var controller_hints := $MarginContainer/VBox/HintsRow/ControllerHints
@onready var screensaver: Control = $Screensaver
@onready var screensaver_clock: Label = $Screensaver/Center/VBox/ClockLabel

const IDLE_TIMEOUT_SECONDS := 180.0
var _idle_timer: Timer

var _continue_game_id: String = ""
var _search_query: String = ""
var _sort_mode: String = "recent"
var _favorites_only: bool = false

const GameCardScene := preload("res://scenes/GameCard.tscn")
const GameDetailScene := preload("res://scenes/GameDetail.tscn")

var _focused_game_id: String = ""


func _ready() -> void:
	SettingsData.apply_theme()
	SettingsData.settings_changed.connect(_apply_settings)

	GameLibrary.library_changed.connect(_refresh_grid)
	GameLibrary.playtime_tick.connect(_on_playtime_tick)
	GameLibrary.achievement_unlocked.connect(_on_achievement_unlocked)

	sort_option.clear()
	sort_option.add_item("Недавние", 0)
	sort_option.add_item("По алфавиту", 1)
	sort_option.add_item("По времени игры", 2)
	sort_option.item_selected.connect(_on_sort_selected)
	search_edit.text_changed.connect(_on_search_changed)
	favorites_filter_button.toggled.connect(_on_favorites_filter_toggled)

	context_menu.add_item("Переименовать", 0)
	context_menu.add_item("Сменить обложку", 1)
	context_menu.add_item("Удалить из лаунчера", 2)
	context_menu.id_pressed.connect(_on_context_menu_id_pressed)

	var clock_timer := Timer.new()
	clock_timer.wait_time = 1.0
	clock_timer.autostart = true
	clock_timer.timeout.connect(_update_clock)
	add_child(clock_timer)
	_update_clock()

	# ---------- Экран отдыха при бездействии ----------
	# Как на настоящих консолях: если долго ничего не трогать на главном
	# экране, гасим интерфейс большими часами - нажатие любой клавиши,
	# кнопки геймпада или движение мыши возвращают в лаунчер. Стик
	# геймпада намеренно не считается активностью (InputEventJoypadMotion
	# отфильтрован в _input) - многие геймпады шлют мелкий "дрейф" оси
	# даже в покое, иначе экран отдыха никогда бы не включился.
	_idle_timer = Timer.new()
	_idle_timer.one_shot = true
	_idle_timer.timeout.connect(_show_screensaver)
	add_child(_idle_timer)
	_restart_idle_timer()

	_setup_user_badge()
	_apply_settings()
	_refresh_grid()

	controller_hints.set_hints([
		{"kind": 0, "keyboard": "ENTER", "text": "Открыть игру"},
		{"kind": 2, "keyboard": "F1", "text": "Меню карточки"},
		{"kind": 3, "keyboard": "F", "text": "В избранное"},
		{"kind": 1, "keyboard": "ESC", "text": "Настройки"},
	])

	modulate.a = 0.0
	if SettingsData.get_animations_enabled():
		var tw := create_tween()
		tw.tween_property(self, "modulate:a", 1.0, 0.4)
	else:
		modulate.a = 1.0


func _setup_user_badge() -> void:
	var u := UserManager.get_user(UserManager.current_user_id)
	if u.is_empty():
		user_name_label.text = ""
		return
	user_avatar.setup(u.get("name", ""), u.get("accent_color", "#4f9dde"), u.get("avatar_path", ""))
	user_name_label.text = u.get("name", "")


func _apply_settings() -> void:
	game_grid.columns = SettingsData.get_columns()
	_update_background()


func _update_background() -> void:
	var style := SettingsData.get_background_style()
	var accent := Color(SettingsData.get_accent_color())

	bg_cover.visible = false
	bg_gradient.visible = false
	bg_animated.visible = false
	# Базовый тёмный цвет по умолчанию - виден только в режиме "Сплошной цвет"
	# или как подложка под остальными режимами, если что-то не загрузилось.
	bg_color_rect.color = Color(0.05, 0.06, 0.09, 1.0)

	match style:
		"gradient":
			bg_gradient.visible = true
			_apply_gradient_colors(accent)
			bg_dim.color.a = 0.15
		"solid":
			# Чтобы было явно видно отличие от остальных режимов, сплошной
			# цвет подстраивается под выбранный акцентный цвет интерфейса.
			bg_color_rect.color = accent.darkened(0.82)
			bg_dim.color.a = 0.1
		"animated":
			bg_animated.visible = true
			var mat := bg_animated.material as ShaderMaterial
			if mat != null:
				mat.set_shader_parameter("accent_color", accent)
			bg_dim.color.a = 0.2
		_:
			# "cover" - размытая обложка последней запущенной игры
			var path := _get_last_cover_path()
			if not path.is_empty() and FileAccess.file_exists(path):
				var img := Image.new()
				if img.load(path) == OK:
					bg_cover.texture = ImageTexture.create_from_image(img)
					bg_cover.visible = true
			bg_dim.color.a = 0.45


func _apply_gradient_colors(accent: Color) -> void:
	var grad_texture := bg_gradient.texture as GradientTexture2D
	if grad_texture == null or grad_texture.gradient == null:
		return
	var top := accent.darkened(0.35)
	var bottom := Color(0.03, 0.035, 0.05, 1.0)
	grad_texture.gradient.colors = PackedColorArray([top, bottom])


func _get_last_cover_path() -> String:
	var best := {}
	for g in GameLibrary.games:
		if not String(g.get("cover_path", "")).is_empty():
			if best.is_empty() or String(g.get("last_played", "")) > String(best.get("last_played", "")):
				best = g
	return best.get("cover_path", "")


func _update_continue_card() -> void:
	var best := {}
	for g in GameLibrary.games:
		if not String(g.get("last_played", "")).is_empty():
			if best.is_empty() or String(g.get("last_played", "")) > String(best.get("last_played", "")):
				best = g

	if best.is_empty():
		continue_card.visible = false
		_continue_game_id = ""
		return

	_continue_game_id = best["id"]
	continue_name_label.text = best.get("name", "")

	var cover_path: String = best.get("cover_path", "")
	if not cover_path.is_empty() and FileAccess.file_exists(cover_path):
		var img := Image.new()
		if img.load(cover_path) == OK:
			continue_cover.texture = ImageTexture.create_from_image(img)

	continue_card.visible = true


func _on_continue_play_pressed() -> void:
	if _continue_game_id.is_empty():
		return
	SettingsData.vibrate(0.4, 0.7, 0.15)
	GameLibrary.launch_game(_continue_game_id)


func _on_search_changed(text: String) -> void:
	_search_query = text
	_refresh_grid()


func _on_favorites_filter_toggled(pressed: bool) -> void:
	_favorites_only = pressed
	_refresh_grid()


func _on_sort_selected(idx: int) -> void:
	match idx:
		1:
			_sort_mode = "alpha"
		2:
			_sort_mode = "playtime"
		_:
			_sort_mode = "recent"
	_refresh_grid()


## Избранные игры всегда идут первыми, дальше - по выбранному режиму сортировки.
func _compare_games(a: Dictionary, b: Dictionary) -> bool:
	var fa := bool(a.get("favorite", false))
	var fb := bool(b.get("favorite", false))
	if fa != fb:
		return fa

	match _sort_mode:
		"alpha":
			return String(a.get("name", "")).to_lower() < String(b.get("name", "")).to_lower()
		"playtime":
			return int(a.get("playtime_seconds", 0)) > int(b.get("playtime_seconds", 0))
		_:
			return String(a.get("last_played", "")) > String(b.get("last_played", ""))


func _get_visible_games() -> Array:
	var list: Array = GameLibrary.games.duplicate()

	if _favorites_only:
		list = list.filter(func(g: Dictionary) -> bool: return bool(g.get("favorite", false)))

	if not _search_query.is_empty():
		var q := _search_query.to_lower()
		list = list.filter(func(g: Dictionary) -> bool:
			return String(g.get("name", "")).to_lower().find(q) != -1
		)

	list.sort_custom(_compare_games)
	return list


func _refresh_grid() -> void:
	for child in game_grid.get_children():
		child.queue_free()

	var i := 0
	for game in _get_visible_games():
		var card := GameCardScene.instantiate()
		game_grid.add_child(card)
		card.setup(game)
		card.open_requested.connect(_on_card_open_requested)
		card.menu_requested.connect(_on_card_menu_requested)

		if SettingsData.get_animations_enabled():
			card.modulate.a = 0.0
			var tw := create_tween()
			tw.tween_interval(i * 0.035)
			tw.tween_property(card, "modulate:a", 1.0, 0.25)
		i += 1

	_update_background()
	_update_continue_card()

	await get_tree().process_frame
	if game_grid.get_child_count() > 0:
		game_grid.get_child(0).grab_focus()


func _on_card_open_requested(game_id: String) -> void:
	var game := GameLibrary.get_game(game_id)
	if game.is_empty():
		return
	var detail := GameDetailScene.instantiate()
	add_child(detail)
	detail.setup(game_id)
	detail.rename_requested.connect(_prompt_rename)
	detail.cover_requested.connect(func(gid: String) -> void: add_game_dialog.open_for_cover(gid))
	detail.delete_requested.connect(func(gid: String) -> void: GameLibrary.remove_game(gid))


func _on_card_menu_requested(game_id: String) -> void:
	_focused_game_id = game_id
	context_menu.popup_centered()


func _on_context_menu_id_pressed(id: int) -> void:
	match id:
		0:
			_prompt_rename(_focused_game_id)
		1:
			add_game_dialog.open_for_cover(_focused_game_id)
		2:
			GameLibrary.remove_game(_focused_game_id)


func _prompt_rename(game_id: String) -> void:
	var game := GameLibrary.get_game(game_id)
	if game.is_empty():
		return

	var dialog := AcceptDialog.new()
	dialog.title = "Переименовать игру"

	var line_edit := LineEdit.new()
	line_edit.text = game["name"]
	line_edit.custom_minimum_size = Vector2(320, 0)
	dialog.add_child(line_edit)

	add_child(dialog)
	dialog.confirmed.connect(func() -> void:
		GameLibrary.rename_game(game_id, line_edit.text)
		dialog.queue_free()
	)
	dialog.canceled.connect(func() -> void:
		dialog.queue_free()
	)
	dialog.popup_centered()
	line_edit.grab_focus()


func _on_playtime_tick(game_id: String, session_seconds: int) -> void:
	for card in game_grid.get_children():
		if card.get_game_id() == game_id:
			card.update_live_playtime(session_seconds)


func _update_clock() -> void:
	var text := Time.get_time_string_from_system().substr(0, 5)
	clock_label.text = text
	if screensaver.visible:
		screensaver_clock.text = text


func _restart_idle_timer() -> void:
	if not SettingsData.get_screensaver_enabled():
		_idle_timer.stop()
		return
	_idle_timer.start(IDLE_TIMEOUT_SECONDS)


func _show_screensaver() -> void:
	if not SettingsData.get_screensaver_enabled():
		return
	screensaver_clock.text = Time.get_time_string_from_system().substr(0, 5)
	screensaver.modulate.a = 0.0
	screensaver.visible = true
	var tw := create_tween()
	tw.tween_property(screensaver, "modulate:a", 1.0, 0.8)


func _hide_screensaver() -> void:
	if not screensaver.visible:
		return
	var tw := create_tween()
	tw.tween_property(screensaver, "modulate:a", 0.0, 0.25)
	tw.tween_callback(func() -> void: screensaver.visible = false)
	_restart_idle_timer()


## Считаем "активностью" только реальный ввод человека - клавиатуру, мышь
## и НАЖАТИЯ кнопок геймпада. InputEventJoypadMotion намеренно не входит
## сюда: у многих геймпадов стики шлют мелкие колебания оси даже когда их
## никто не трогает, и с ними экран отдыха либо никогда бы не включался,
## либо мгновенно гас бы обратно после появления.
func _is_activity_event(event: InputEvent) -> bool:
	return event is InputEventKey or event is InputEventMouseButton \
		or event is InputEventMouseMotion or event is InputEventJoypadButton


func _input(event: InputEvent) -> void:
	if not _is_activity_event(event):
		return

	if screensaver.visible:
		get_viewport().set_input_as_handled()
		_hide_screensaver()
		return

	_restart_idle_timer()


func _on_add_game_button_pressed() -> void:
	add_game_dialog.open_for_new_game()


func _on_shop_button_pressed() -> void:
	Transitions.fade_to_scene("res://scenes/Shop.tscn")


func _on_browser_button_pressed() -> void:
	Transitions.fade_to_scene("res://scenes/Browser.tscn")


func _on_stats_button_pressed() -> void:
	Transitions.fade_to_scene("res://scenes/Stats.tscn")


func _on_friends_button_pressed() -> void:
	Transitions.fade_to_scene("res://scenes/Friends.tscn")


## "Что поиграть?" - открывает экран случайной игры из библиотеки текущего
## профиля, чтобы не листать сетку самому, если лень выбирать.
func _on_random_game_pressed() -> void:
	if GameLibrary.games.is_empty():
		var dialog := AcceptDialog.new()
		dialog.title = "Библиотека пуста"
		dialog.dialog_text = "Сначала добавь хотя бы одну игру кнопкой «Добавить игру»."
		add_child(dialog)
		dialog.confirmed.connect(func() -> void: dialog.queue_free())
		dialog.canceled.connect(func() -> void: dialog.queue_free())
		dialog.popup_centered()
		return

	var pick: Dictionary = GameLibrary.games[randi() % GameLibrary.games.size()]
	SettingsData.vibrate(0.2, 0.3, 0.08)
	_on_card_open_requested(pick["id"])


func _on_settings_button_pressed() -> void:
	var settings_scene := preload("res://scenes/Settings.tscn")
	var settings := settings_scene.instantiate()
	add_child(settings)


func _on_switch_user_pressed() -> void:
	Transitions.fade_to_scene("res://scenes/ProfileSelect.tscn")


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("open_menu"):
		var focused := get_viewport().gui_get_focus_owner()
		if focused and focused.has_method("get_game_id"):
			_on_card_menu_requested(focused.get_game_id())
	elif event.is_action_pressed("toggle_favorite"):
		var focused_card := get_viewport().gui_get_focus_owner()
		if focused_card and focused_card.has_method("get_game_id"):
			var gid: String = focused_card.get_game_id()
			GameLibrary.toggle_favorite(gid)
			var game := GameLibrary.get_game(gid)
			focused_card.set_favorite(bool(game.get("favorite", false)))
	elif event.is_action_pressed("ui_cancel"):
		_on_settings_button_pressed()


func _on_achievement_unlocked(_id: String, title: String) -> void:
	_show_achievement_toast(title)


func _show_achievement_toast(title: String) -> void:
	SettingsData.vibrate(0.3, 0.5, 0.12)

	var panel := PanelContainer.new()
	panel.modulate.a = 0.0
	panel.anchor_left = 1.0
	panel.anchor_right = 1.0
	panel.anchor_top = 1.0
	panel.anchor_bottom = 1.0
	panel.offset_left = -380.0
	panel.offset_right = -24.0
	panel.offset_top = -110.0
	panel.offset_bottom = -24.0
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(panel)

	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 14)
	panel.add_child(hbox)

	var icon := Label.new()
	icon.text = "🏆"
	icon.add_theme_font_size_override("font_size", 34)
	hbox.add_child(icon)

	var vb := VBoxContainer.new()
	vb.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hbox.add_child(vb)

	var caption := Label.new()
	caption.text = "Достижение получено"
	caption.add_theme_font_size_override("font_size", 12)
	caption.modulate = Color(0.7, 0.75, 0.8, 1)
	vb.add_child(caption)

	var name_lbl := Label.new()
	name_lbl.text = title
	name_lbl.add_theme_font_size_override("font_size", 19)
	vb.add_child(name_lbl)

	var tw := create_tween()
	tw.tween_property(panel, "modulate:a", 1.0, 0.25)
	tw.tween_interval(3.2)
	tw.tween_property(panel, "modulate:a", 0.0, 0.4)
	tw.tween_callback(panel.queue_free)
