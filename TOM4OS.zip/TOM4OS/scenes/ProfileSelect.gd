extends Control
## Экран выбора профиля - показывается при каждом запуске лаунчера,
## чтобы у каждого профиля была своя личная библиотека игр. После выбора
## (или создания) профиля GameLibrary переключается на его личную библиотеку.

const CreateUserDialogScene := preload("res://scenes/CreateUserDialog.tscn")
const AvatarScene := preload("res://scenes/AvatarView.tscn")

@onready var profiles_row: HFlowContainer = $CenterContainer/VBox/ProfilesRow
@onready var bg_animated: ColorRect = $BgAnimated
@onready var controller_hints := $BottomHints/ControllerHints


func _ready() -> void:
	SettingsData.apply_theme()
	UserManager.users_changed.connect(_refresh)

	var mat := bg_animated.material as ShaderMaterial
	if mat != null:
		mat.set_shader_parameter("accent_color", Color(SettingsData.get_accent_color()))

	controller_hints.set_hints([
		{"kind": 0, "keyboard": "ENTER", "text": "Выбрать профиль"},
	])

	_refresh()


func _refresh() -> void:
	for c in profiles_row.get_children():
		c.queue_free()

	for u in UserManager.users:
		profiles_row.add_child(_make_tile(u))
	profiles_row.add_child(_make_add_tile())

	await get_tree().process_frame
	if profiles_row.get_child_count() > 0:
		profiles_row.get_child(0).grab_focus()


func _make_tile(u: Dictionary) -> Control:
	var vb := VBoxContainer.new()
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.custom_minimum_size = Vector2(160, 0)
	vb.add_theme_constant_override("separation", 10)

	var btn := Button.new()
	btn.custom_minimum_size = Vector2(140, 140)
	btn.flat = true
	btn.focus_mode = Control.FOCUS_ALL

	var avatar := AvatarScene.instantiate()
	avatar.custom_minimum_size = Vector2(140, 140)
	avatar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	avatar.set_anchors_preset(Control.PRESET_FULL_RECT)
	btn.add_child(avatar)
	avatar.setup(u.get("name", ""), u.get("accent_color", "#4f9dde"), u.get("avatar_path", ""))

	var user_id: String = u["id"]
	btn.pressed.connect(func() -> void: _select_user(user_id))
	btn.focus_entered.connect(func() -> void: _animate_scale(btn, 1.08))
	btn.focus_exited.connect(func() -> void: _animate_scale(btn, 1.0))
	btn.mouse_entered.connect(func() -> void: _animate_scale(btn, 1.08))
	btn.mouse_exited.connect(func() -> void:
		if not btn.has_focus():
			_animate_scale(btn, 1.0)
	)

	vb.add_child(btn)

	var lbl := Label.new()
	lbl.text = u.get("name", "")
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(lbl)

	var stats := _get_user_stats(user_id)
	var stats_lbl := Label.new()
	stats_lbl.text = tr("%d игр · %s") % [stats["count"], GameLibrary.format_playtime(stats["seconds"])]
	stats_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	stats_lbl.add_theme_font_size_override("font_size", 12)
	stats_lbl.modulate = Color(0.65, 0.7, 0.75, 1)
	vb.add_child(stats_lbl)

	return vb


## Читает библиотеку конкретного профиля напрямую из файла, не переключая
## текущего пользователя в GameLibrary - нужно только для маленькой подписи
## "N игр · X" под аватаркой на этом экране.
func _get_user_stats(user_id: String) -> Dictionary:
	var path := "user://users/%s/games.json" % user_id
	if not FileAccess.file_exists(path):
		return {"count": 0, "seconds": 0}

	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {"count": 0, "seconds": 0}
	var text := file.get_as_text()
	file.close()

	var parsed = JSON.parse_string(text)
	if typeof(parsed) != TYPE_DICTIONARY or not parsed.has("games"):
		return {"count": 0, "seconds": 0}

	var game_list: Array = parsed["games"]
	var total_seconds := 0
	for g in game_list:
		total_seconds += int(g.get("playtime_seconds", 0))

	return {"count": game_list.size(), "seconds": total_seconds}


func _make_add_tile() -> Control:
	var vb := VBoxContainer.new()
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.custom_minimum_size = Vector2(160, 0)
	vb.add_theme_constant_override("separation", 10)

	var btn := Button.new()
	btn.custom_minimum_size = Vector2(140, 140)
	btn.text = "+"
	btn.add_theme_font_size_override("font_size", 48)
	btn.focus_mode = Control.FOCUS_ALL
	btn.pressed.connect(_on_add_pressed)
	btn.focus_entered.connect(func() -> void: _animate_scale(btn, 1.08))
	btn.focus_exited.connect(func() -> void: _animate_scale(btn, 1.0))
	btn.mouse_entered.connect(func() -> void: _animate_scale(btn, 1.08))
	btn.mouse_exited.connect(func() -> void:
		if not btn.has_focus():
			_animate_scale(btn, 1.0)
	)
	vb.add_child(btn)

	var lbl := Label.new()
	lbl.text = "Новый профиль"
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(lbl)

	return vb


func _animate_scale(node: Control, target: float) -> void:
	if not SettingsData.get_animations_enabled():
		node.scale = Vector2(target, target)
		return
	node.pivot_offset = node.size / 2.0
	var tw := create_tween()
	tw.tween_property(node, "scale", Vector2(target, target), 0.15).set_trans(Tween.TRANS_SINE)


func _on_add_pressed() -> void:
	var dlg := CreateUserDialogScene.instantiate()
	add_child(dlg)
	dlg.user_created.connect(func(u: Dictionary) -> void: _select_user(u["id"]))
	dlg.popup_centered()


func _select_user(user_id: String) -> void:
	SettingsData.vibrate(0.25, 0.4, 0.1)
	UserManager.select_user(user_id)
	GameLibrary.reload_for_current_user()
	FriendsManager.reload_for_current_user()
	Transitions.fade_to_scene("res://scenes/Main.tscn")
