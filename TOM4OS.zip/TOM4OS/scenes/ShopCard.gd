extends Button
## Одна карточка результата поиска по каталогу Steam на экране «Магазин».
## Обложка подгружается асинхронно (см. Shop.gd), сама карточка только
## хранит appid и умеет проиграть анимацию выбора, как GameCard.

@onready var cover_rect: TextureRect = $VBox/CoverRect
@onready var loading_label: Label = $VBox/CoverRect/LoadingLabel
@onready var name_label: Label = $VBox/NameLabel
@onready var owned_badge: Label = $VBox/OwnedBadge

var appid: int = 0


func setup(app_id: int, display_name: String, already_owned: bool) -> void:
	appid = app_id
	name_label.text = display_name
	owned_badge.visible = already_owned


func set_cover_texture(tex: Texture2D) -> void:
	cover_rect.texture = tex
	loading_label.visible = false
