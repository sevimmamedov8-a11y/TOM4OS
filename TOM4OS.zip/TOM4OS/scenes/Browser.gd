extends Control
## Экран «Браузер»: адресная строка + избранные сайты. Открывает адрес в
## уже установленном Firefox (или в браузере по умолчанию, если Firefox не
## найден) - см. autoload/BrowserLauncher.gd, почему это отдельное окно,
## а не веб-страница, нарисованная прямо внутри самого TOM4OS.

@onready var address_edit: LineEdit = $MarginContainer/VBox/AddressBar/AddressEdit
@onready var status_label: Label = $MarginContainer/VBox/StatusLabel
@onready var bookmarks_list: VBoxContainer = $MarginContainer/VBox/ScrollContainer/BookmarksList
@onready var controller_hints := $MarginContainer/VBox/HintsRow/ControllerHints

const BOOKMARKS_PATH := "user://browser_bookmarks.json"

## Сайты по умолчанию - всегда в списке первыми, удалить их нельзя (мало
## смысла терять быстрый доступ к ним по ошибке). Пользователь может
## добавить к ним свои через «★ В избранное».
const DEFAULT_BOOKMARKS: Array[Dictionary] = [
	{"name": "Google", "url": "https://www.google.com"},
	{"name": "YouTube", "url": "https://www.youtube.com"},
	{"name": "Steam", "url": "https://store.steampowered.com"},
	{"name": "ProtonDB", "url": "https://www.protondb.com"},
	{"name": "Twitch", "url": "https://www.twitch.tv"},
	{"name": "Wikipedia", "url": "https://ru.wikipedia.org"},
]

var _custom_bookmarks: Array = []  # Array[Dictionary] {name, url}


func _ready() -> void:
	controller_hints.set_hints([
		{"kind": 0, "keyboard": "ENTER", "text": "Открыть сайт"},
		{"kind": 1, "keyboard": "ESC", "text": "Назад"},
	])

	_load_bookmarks()
	_refresh_bookmarks_list()
	address_edit.grab_focus()


func _on_back_pressed() -> void:
	Transitions.fade_to_scene("res://scenes/Main.tscn")


func _on_go_pressed() -> void:
	_open(address_edit.text)


func _on_address_submitted(text: String) -> void:
	_open(text)


func _open(raw: String) -> void:
	var result := BrowserLauncher.open_url(raw)
	status_label.text = result.get("message", "")
	if result.get("ok", false):
		status_label.modulate = Color(0.55, 0.85, 0.6, 1)
		SettingsData.vibrate(0.2, 0.3, 0.08)
	else:
		status_label.modulate = Color(0.9, 0.5, 0.5, 1)


func _on_add_bookmark_pressed() -> void:
	var url := address_edit.text.strip_edges()
	if url.is_empty():
		status_label.text = "Сначала введи адрес сайта, который хочешь сохранить."
		status_label.modulate = Color(0.9, 0.5, 0.5, 1)
		return

	var dialog := AcceptDialog.new()
	dialog.title = "Добавить в избранное"

	var line_edit := LineEdit.new()
	line_edit.placeholder_text = "Название сайта"
	line_edit.text = url
	line_edit.custom_minimum_size = Vector2(320, 0)
	dialog.add_child(line_edit)

	add_child(dialog)
	dialog.confirmed.connect(func() -> void:
		var display_name := line_edit.text.strip_edges()
		if display_name.is_empty():
			display_name = url
		_custom_bookmarks.append({"name": display_name, "url": BrowserLauncher.normalize_input(url)})
		_save_bookmarks()
		_refresh_bookmarks_list()
		dialog.queue_free()
	)
	dialog.canceled.connect(func() -> void:
		dialog.queue_free()
	)
	dialog.popup_centered()
	line_edit.grab_focus()


# ---------- Хранение закладок пользователя (user://browser_bookmarks.json) ----------
# Общее для всех профилей, как остальные настройки лаунчера - не привязано
# к конкретному пользователю.

func _load_bookmarks() -> void:
	_custom_bookmarks = []
	if not FileAccess.file_exists(BOOKMARKS_PATH):
		return

	var file := FileAccess.open(BOOKMARKS_PATH, FileAccess.READ)
	if file == null:
		return
	var text := file.get_as_text()
	file.close()

	var parsed = JSON.parse_string(text)
	if typeof(parsed) == TYPE_DICTIONARY:
		_custom_bookmarks = parsed.get("bookmarks", [])


func _save_bookmarks() -> void:
	var file := FileAccess.open(BOOKMARKS_PATH, FileAccess.WRITE)
	if file == null:
		push_error("Browser: не удалось сохранить закладки")
		return
	file.store_string(JSON.stringify({"bookmarks": _custom_bookmarks}, "\t"))
	file.close()


func _remove_bookmark(index: int) -> void:
	if index < 0 or index >= _custom_bookmarks.size():
		return
	_custom_bookmarks.remove_at(index)
	_save_bookmarks()
	_refresh_bookmarks_list()


func _refresh_bookmarks_list() -> void:
	for c in bookmarks_list.get_children():
		c.queue_free()

	for b in DEFAULT_BOOKMARKS:
		bookmarks_list.add_child(_make_bookmark_row(b["name"], b["url"], -1))

	for i in _custom_bookmarks.size():
		var b: Dictionary = _custom_bookmarks[i]
		bookmarks_list.add_child(_make_bookmark_row(b.get("name", ""), b.get("url", ""), i))


## custom_index >= 0 для закладок, которые добавил сам пользователь - у них
## есть кнопка удаления. У закладок по умолчанию (-1) её нет.
func _make_bookmark_row(display_name: String, url: String, custom_index: int) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)

	var open_btn := Button.new()
	open_btn.text = display_name
	open_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	open_btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
	open_btn.pressed.connect(func() -> void: _open(url))
	row.add_child(open_btn)

	if custom_index >= 0:
		var del_btn := Button.new()
		del_btn.text = "✕"
		del_btn.custom_minimum_size = Vector2(40, 0)
		del_btn.tooltip_text = "Удалить из избранного"
		del_btn.pressed.connect(func() -> void: _remove_bookmark(custom_index))
		row.add_child(del_btn)

	return row
