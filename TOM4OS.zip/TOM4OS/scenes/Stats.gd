extends Control
## Экран «Статистика»: сводка по библиотеке текущего профиля - сколько
## игр, сколько всего наиграно, самая любимая игра, достижения и т.д.
## Всё считается на лету из GameLibrary.games при открытии экрана.

@onready var stats_grid: GridContainer = $MarginContainer/VBox/StatsGrid
@onready var top_games_list: VBoxContainer = $MarginContainer/VBox/TopGamesList
@onready var controller_hints := $MarginContainer/VBox/HintsRow/ControllerHints


func _ready() -> void:
	controller_hints.set_hints([
		{"kind": 1, "keyboard": "ESC", "text": "Назад"},
	])
	_build_stats()


func _on_back_pressed() -> void:
	Transitions.fade_to_scene("res://scenes/Main.tscn")


func _build_stats() -> void:
	for c in stats_grid.get_children():
		c.queue_free()
	for c in top_games_list.get_children():
		c.queue_free()

	var games: Array = GameLibrary.games
	var total_games := games.size()
	var total_seconds := 0
	var favorites_count := 0
	var earliest_added: float = -1.0

	for g in games:
		total_seconds += int(g.get("playtime_seconds", 0))
		if bool(g.get("favorite", false)):
			favorites_count += 1
		var added_at := float(g.get("added_at", 0))
		if added_at > 0 and (earliest_added < 0 or added_at < earliest_added):
			earliest_added = added_at

	var unlocked_count := GameLibrary.unlocked_achievements.size()
	var achievements_total := GameLibrary.ACHIEVEMENTS.size()
	var avg_seconds := 0 if total_games == 0 else int(total_seconds / float(total_games))

	var member_since := "-"
	if earliest_added > 0:
		var dt := Time.get_datetime_dict_from_unix_time(int(earliest_added))
		member_since = "%04d-%02d-%02d" % [dt["year"], dt["month"], dt["day"]]

	_add_stat_card("Игр в библиотеке", str(total_games))
	_add_stat_card("Всего наиграно", GameLibrary.format_playtime(total_seconds))
	_add_stat_card("Среднее на игру", GameLibrary.format_playtime(avg_seconds))
	_add_stat_card("В избранном", str(favorites_count))
	_add_stat_card("Достижения", "%d / %d" % [unlocked_count, achievements_total])
	_add_stat_card("Первая игра добавлена", member_since)

	var top_label := Label.new()
	top_label.text = "Больше всего наиграно"
	top_label.add_theme_font_size_override("font_size", 20)
	top_games_list.add_child(top_label)

	if games.is_empty():
		var empty_lbl := Label.new()
		empty_lbl.text = "Библиотека пуста - добавь игру на главном экране."
		empty_lbl.modulate = Color(0.6, 0.65, 0.7, 1)
		top_games_list.add_child(empty_lbl)
		return

	var sorted_games: Array = games.duplicate()
	sorted_games.sort_custom(func(a, b): return int(a.get("playtime_seconds", 0)) > int(b.get("playtime_seconds", 0)))

	var shown := 0
	for g in sorted_games:
		if int(g.get("playtime_seconds", 0)) <= 0:
			continue
		top_games_list.add_child(_make_top_game_row(g, shown + 1))
		shown += 1
		if shown >= 5:
			break

	if shown == 0:
		var none_lbl := Label.new()
		none_lbl.text = "Пока ни одной сыгранной сессии."
		none_lbl.modulate = Color(0.6, 0.65, 0.7, 1)
		top_games_list.add_child(none_lbl)


func _add_stat_card(title: String, value: String) -> void:
	var panel := PanelContainer.new()
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 4)
	panel.add_child(vb)

	var value_lbl := Label.new()
	value_lbl.text = value
	value_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	value_lbl.add_theme_font_size_override("font_size", 30)
	vb.add_child(value_lbl)

	var title_lbl := Label.new()
	title_lbl.text = title
	title_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title_lbl.add_theme_font_size_override("font_size", 13)
	title_lbl.modulate = Color(0.7, 0.75, 0.8, 1)
	vb.add_child(title_lbl)

	stats_grid.add_child(panel)


func _make_top_game_row(g: Dictionary, rank: int) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)

	var rank_lbl := Label.new()
	rank_lbl.text = "#%d" % rank
	rank_lbl.custom_minimum_size = Vector2(36, 0)
	rank_lbl.modulate = Color(0.7, 0.75, 0.8, 1)
	row.add_child(rank_lbl)

	var name_lbl := Label.new()
	name_lbl.text = String(g.get("name", ""))
	name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(name_lbl)

	var time_lbl := Label.new()
	time_lbl.text = GameLibrary.format_playtime(int(g.get("playtime_seconds", 0)))
	time_lbl.modulate = Color(0.7, 0.75, 0.8, 1)
	row.add_child(time_lbl)

	return row
