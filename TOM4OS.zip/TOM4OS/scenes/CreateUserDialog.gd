extends Window
## Окно создания нового профиля или редактирования уже существующего:
## имя, фото (по желанию) и акцентный цвет.

signal user_created(user: Dictionary)
signal user_updated(user: Dictionary)

@onready var title_label: Label = $VBox/TitleLabel
@onready var name_edit: LineEdit = $VBox/NameEdit
@onready var avatar_preview := $VBox/PreviewRow/AvatarPreview
@onready var image_dialog: FileDialog = $ImageFileDialog
@onready var swatches_row: HBoxContainer = $VBox/SwatchesRow
@onready var create_button: Button = $VBox/Buttons/CreateButton

const COLORS: Array[String] = [
	"#4f9dde", "#e5636b", "#59c48a", "#caa23e",
	"#9b6fd1", "#3fb8c9", "#e8935a", "#7fd1c9",
]

var _avatar_path: String = ""
var _accent_color: String = "#4f9dde"
var _editing_user_id: String = ""


func _ready() -> void:
	image_dialog.add_filter("*.png,*.jpg,*.jpeg ; Изображения")

	for hex: String in COLORS:
		var b := Button.new()
		b.custom_minimum_size = Vector2(36, 36)
		b.toggle_mode = true
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(hex)
		sb.corner_radius_top_left = 8
		sb.corner_radius_top_right = 8
		sb.corner_radius_bottom_left = 8
		sb.corner_radius_bottom_right = 8
		b.add_theme_stylebox_override("normal", sb)
		b.add_theme_stylebox_override("hover", sb)
		b.add_theme_stylebox_override("pressed", sb)
		b.add_theme_stylebox_override("focus", sb)
		var hex_captured: String = hex
		b.pressed.connect(func() -> void:
			_accent_color = hex_captured
			_update_preview()
		)
		swatches_row.add_child(b)

	name_edit.text_changed.connect(func(_t: String) -> void: _update_preview())
	_update_preview()
	name_edit.grab_focus()


## Переключает окно в режим редактирования уже существующего профиля:
## подставляет его текущие имя, фото и цвет, меняет заголовок и кнопку.
func setup_for_edit(user_id: String) -> void:
	var u := UserManager.get_user(user_id)
	if u.is_empty():
		return

	_editing_user_id = user_id
	_avatar_path = u.get("avatar_path", "")
	_accent_color = u.get("accent_color", "#4f9dde")

	title = "Редактировать профиль"
	title_label.text = "Редактировать профиль"
	create_button.text = "Сохранить"

	if is_inside_tree():
		name_edit.text = u.get("name", "")
	else:
		# @onready ещё не сработал - дождёмся входа в дерево.
		ready.connect(func() -> void:
			name_edit.text = u.get("name", "")
			_update_preview()
		, CONNECT_ONE_SHOT)
		return

	_update_preview()


func _update_preview() -> void:
	var n := name_edit.text
	if n.is_empty():
		n = "?"
	avatar_preview.setup(n, _accent_color, _avatar_path)


func _on_browse_photo_pressed() -> void:
	image_dialog.popup_centered_ratio(0.6)


func _on_image_selected(path: String) -> void:
	_avatar_path = path
	_update_preview()


func _on_create_pressed() -> void:
	var n := name_edit.text.strip_edges()
	if n.is_empty():
		n = "Игрок"

	if _editing_user_id.is_empty():
		var u := UserManager.create_user(n, _avatar_path, _accent_color)
		user_created.emit(u)
	else:
		UserManager.rename_user(_editing_user_id, n)
		UserManager.set_user_avatar(_editing_user_id, _avatar_path)
		UserManager.set_user_accent(_editing_user_id, _accent_color)
		user_updated.emit(UserManager.get_user(_editing_user_id))

	queue_free()


func _on_cancel_pressed() -> void:
	queue_free()


func _on_close_requested() -> void:
	queue_free()
