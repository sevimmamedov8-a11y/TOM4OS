extends Control
## Экран «Магазин»: поиск по официальному публичному каталогу Steam.
## Ничего не скачивается напрямую - у каждой найденной игры можно открыть
## карточку и либо добавить её в библиотеку (запуск через steam://,
## устанавливает и запускает игру уже установленный у пользователя клиент
## Steam), либо просто открыть её страницу в Steam.

@onready var search_edit: LineEdit = $MarginContainer/VBox/TopBar/SearchEdit
@onready var status_label: Label = $MarginContainer/VBox/StatusLabel
@onready var results_grid: GridContainer = $MarginContainer/VBox/ScrollContainer/ResultsGrid
@onready var controller_hints := $MarginContainer/VBox/HintsRow/ControllerHints

const ShopCardScene := preload("res://scenes/ShopCard.tscn")
const ShopGameDetailScene := preload("res://scenes/ShopGameDetail.tscn")

var _search_token: int = 0  # чтобы старый поиск не затирал результаты нового


func _ready() -> void:
	controller_hints.set_hints([
		{"kind": 0, "keyboard": "ENTER", "text": "Открыть карточку"},
		{"kind": 1, "keyboard": "ESC", "text": "Назад"},
	])
	search_edit.grab_focus()


func _on_back_pressed() -> void:
	Transitions.fade_to_scene("res://scenes/Main.tscn")


func _on_search_pressed() -> void:
	_run_search(search_edit.text)


func _on_search_submitted(text: String) -> void:
	_run_search(text)


func _run_search(query: String) -> void:
	query = query.strip_edges()
	if query.is_empty():
		return

	_search_token += 1
	var my_token := _search_token

	for c in results_grid.get_children():
		c.queue_free()
	status_label.text = tr("Ищу «%s» в каталоге Steam...") % query

	var items: Array = await SteamService.search_catalog(query)

	if my_token != _search_token:
		return  # пользователь уже запустил новый поиск - этот результат устарел

	if items.is_empty():
		status_label.text = tr("Ничего не найдено.")
		return

	status_label.text = tr("Найдено: %d") % items.size()
	_populate_results(items)


func _populate_results(items: Array) -> void:
	var first_card: Control = null

	for item in items:
		var appid := int(item.get("id", 0))
		if appid <= 0:
			continue

		var card := ShopCardScene.instantiate()
		results_grid.add_child(card)
		var owned := not GameLibrary.find_by_steam_appid(appid).is_empty()
		card.setup(appid, String(item.get("name", "")), owned)
		card.pressed.connect(_on_card_pressed.bind(appid))

		if first_card == null:
			first_card = card

		var thumb_url: String = item.get("tiny_image", "")
		if not thumb_url.is_empty():
			_load_card_thumbnail(card, thumb_url)

	if first_card:
		first_card.grab_focus()


func _load_card_thumbnail(card: Control, url: String) -> void:
	var bytes: PackedByteArray = await SteamService.fetch_image_bytes(url)
	if not is_instance_valid(card) or bytes.is_empty():
		return

	var img := Image.new()
	var err := img.load_jpg_from_buffer(bytes)
	if err != OK:
		err = img.load_png_from_buffer(bytes)
	if err != OK:
		return

	card.set_cover_texture(ImageTexture.create_from_image(img))


func _on_card_pressed(appid: int) -> void:
	var detail := ShopGameDetailScene.instantiate()
	add_child(detail)
	detail.setup(appid)
