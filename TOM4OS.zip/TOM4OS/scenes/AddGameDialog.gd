extends Window
## Окно добавления игры / смены обложки.
## Все сигналы кнопок и диалогов подключены прямо в AddGameDialog.tscn.

@onready var exe_file_dialog: FileDialog = $ExeFileDialog
@onready var image_file_dialog: FileDialog = $ImageFileDialog
@onready var status_label: Label = $VBox/StatusLabel
@onready var browse_exe_button: Button = $VBox/BrowseExeButton
@onready var browse_image_button: Button = $VBox/BrowseImageButton

var _pending_game_id: String = ""


func _ready() -> void:
	exe_file_dialog.add_filter("*.exe ; Исполняемые файлы Windows")
	image_file_dialog.add_filter("*.png,*.jpg,*.jpeg ; Изображения")


func open_for_new_game() -> void:
	status_label.text = "Нажмите «Выбрать .exe» и укажите исполняемый файл игры"
	browse_exe_button.visible = true
	browse_image_button.visible = false
	popup_centered()


func open_for_cover(game_id: String) -> void:
	_pending_game_id = game_id
	status_label.text = "Выберите картинку для обложки"
	browse_exe_button.visible = false
	browse_image_button.visible = true
	popup_centered()


func _on_browse_exe_pressed() -> void:
	exe_file_dialog.popup_centered_ratio(0.6)


func _on_browse_image_pressed() -> void:
	image_file_dialog.popup_centered_ratio(0.6)


func _on_close_button_pressed() -> void:
	hide()


func _on_close_requested() -> void:
	hide()


func _on_exe_selected(path: String) -> void:
	var game := GameLibrary.add_game(path)
	_pending_game_id = game["id"]
	status_label.text = tr("Добавлено: %s") % game["name"]

	# Обложка ставится автоматически: пытаемся взять её прямо из иконки .exe
	if SettingsData.get_auto_icon_enabled():
		status_label.text = "Извлекаю иконку из .exe..."
		var ok := GameLibrary.auto_set_cover_from_exe(_pending_game_id)
		if ok:
			status_label.text = "Готово! Обложка взята из иконки игры."
			return
		else:
			status_label.text = "Не удалось получить иконку из .exe."

	# Резервный вариант - поиск по SteamGridDB, если задан ключ в настройках
	var api_key: String = SettingsData.get_steamgriddb_key()
	if not api_key.is_empty():
		status_label.text = "Ищу обложку в SteamGridDB..."
		await GameLibrary.fetch_cover_from_steamgriddb(_pending_game_id, api_key)
		status_label.text = "Готово! Можно закрыть окно."
	else:
		status_label.text += "\nОбложку можно задать вручную через меню карточки."


func _on_image_selected(path: String) -> void:
	GameLibrary.set_cover(_pending_game_id, path)
	status_label.text = "Обложка обновлена. Можно закрыть окно."
