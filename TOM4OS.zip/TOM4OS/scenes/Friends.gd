extends Control
## Экран «Друзья»: локальный список контактов текущего профиля. Если в
## Настройках → Steam указан свой API-ключ, для друзей с привязанным
## Steam-профилем (ник, SteamID64 или ссылка steamcommunity.com/id/...)
## подтягивается их реальный статус - онлайн/офлайн/в какой игре сейчас
## играют. Это данные с серверов самого Steam, поэтому честно работает
## между разными компьютерами - см. FriendsManager.gd про то, почему
## "настоящих" друзей внутри самого TOM4OS без своего сервера не сделать.

@onready var friends_list: VBoxContainer = $MarginContainer/VBox/ScrollContainer/FriendsList
@onready var info_label: Label = $MarginContainer/VBox/InfoLabel
@onready var controller_hints := $MarginContainer/VBox/HintsRow/ControllerHints


func _ready() -> void:
	controller_hints.set_hints([
		{"kind": 1, "keyboard": "ESC", "text": "Назад"},
	])

	FriendsManager.friends_changed.connect(_refresh_list)
	FriendsManager.statuses_updated.connect(_refresh_list)

	_update_info_label()
	_refresh_list()
	FriendsManager.refresh_statuses()


func _on_back_pressed() -> void:
	Transitions.fade_to_scene("res://scenes/Main.tscn")


func _on_add_friend_pressed() -> void:
	_open_friend_dialog()


func _on_refresh_pressed() -> void:
	FriendsManager.refresh_statuses()


func _update_info_label() -> void:
	if SettingsData.get_steam_api_key().is_empty():
		info_label.text = "Steam API-ключ не задан (Настройки → Steam) - друзья будут просто списком контактов, без живого статуса."
		info_label.modulate = Color(0.75, 0.65, 0.4, 1)
	else:
		info_label.text = "Статус друзей со Steam-профилем подтягивается автоматически раз в минуту."
		info_label.modulate = Color(0.6, 0.65, 0.7, 1)


func _refresh_list() -> void:
	for c in friends_list.get_children():
		c.queue_free()

	if FriendsManager.friends.is_empty():
		var empty_lbl := Label.new()
		empty_lbl.text = "Пока нет ни одного друга - добавь по нику или Steam-ссылке кнопкой выше."
		empty_lbl.modulate = Color(0.6, 0.65, 0.7, 1)
		friends_list.add_child(empty_lbl)
		return

	# Сначала те, кто в игре/онлайн, потом офлайн/локальные контакты.
	var sorted_friends: Array = FriendsManager.friends.duplicate()
	sorted_friends.sort_custom(func(a, b) -> bool:
		var sa: Dictionary = FriendsManager.get_display_status(a)
		var sb: Dictionary = FriendsManager.get_display_status(b)
		if bool(sa["online"]) != bool(sb["online"]):
			return bool(sa["online"])
		return String(a.get("display_name", "")).to_lower() < String(b.get("display_name", "")).to_lower()
	)

	for f in sorted_friends:
		friends_list.add_child(_make_friend_row(f))


func _make_friend_row(friend: Dictionary) -> Control:
	var status := FriendsManager.get_display_status(friend)

	var panel := PanelContainer.new()
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	panel.add_child(row)

	var dot := Label.new()
	dot.text = "●"
	dot.modulate = status["color"]
	dot.custom_minimum_size = Vector2(20, 0)
	row.add_child(dot)

	var vb := VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_theme_constant_override("separation", 2)
	row.add_child(vb)

	var name_lbl := Label.new()
	name_lbl.text = String(friend.get("display_name", ""))
	name_lbl.add_theme_font_size_override("font_size", 18)
	vb.add_child(name_lbl)

	var status_lbl := Label.new()
	status_lbl.text = String(status["text"])
	status_lbl.modulate = status["color"]
	status_lbl.add_theme_font_size_override("font_size", 13)
	vb.add_child(status_lbl)

	var note: String = friend.get("note", "")
	if not note.is_empty():
		var note_lbl := Label.new()
		note_lbl.text = note
		note_lbl.modulate = Color(0.55, 0.6, 0.65, 1)
		note_lbl.add_theme_font_size_override("font_size", 12)
		vb.add_child(note_lbl)

	var edit_btn := Button.new()
	edit_btn.text = "Изменить"
	edit_btn.pressed.connect(func() -> void: _open_friend_dialog(friend))
	row.add_child(edit_btn)

	var del_btn := Button.new()
	del_btn.text = "✕"
	del_btn.custom_minimum_size = Vector2(40, 0)
	del_btn.tooltip_text = "Удалить друга"
	del_btn.pressed.connect(func() -> void: FriendsManager.remove_friend(friend["id"]))
	row.add_child(del_btn)

	return panel


## friend пустой словарь - режим добавления, иначе - редактирование
## существующего.
func _open_friend_dialog(friend: Dictionary = {}) -> void:
	var is_edit := not friend.is_empty()

	var dialog := AcceptDialog.new()
	dialog.title = "Изменить друга" if is_edit else "Добавить друга"

	var vb := VBoxContainer.new()
	vb.custom_minimum_size = Vector2(360, 0)
	vb.add_theme_constant_override("separation", 10)
	dialog.add_child(vb)

	var name_edit := LineEdit.new()
	name_edit.placeholder_text = "Ник (обязательно)"
	name_edit.text = String(friend.get("display_name", ""))
	vb.add_child(name_edit)

	var steam_edit := LineEdit.new()
	steam_edit.placeholder_text = "Steam: ник, SteamID64 или ссылка (необязательно)"
	steam_edit.text = String(friend.get("steam_input", ""))
	vb.add_child(steam_edit)

	var note_edit := LineEdit.new()
	note_edit.placeholder_text = "Заметка (необязательно)"
	note_edit.text = String(friend.get("note", ""))
	vb.add_child(note_edit)

	add_child(dialog)
	dialog.confirmed.connect(func() -> void:
		var display_name := name_edit.text.strip_edges()
		if display_name.is_empty():
			dialog.queue_free()
			return
		if is_edit:
			FriendsManager.update_friend(friend["id"], display_name, steam_edit.text, note_edit.text)
		else:
			FriendsManager.add_friend(display_name, steam_edit.text, note_edit.text)
		dialog.queue_free()
	)
	dialog.canceled.connect(func() -> void: dialog.queue_free())
	dialog.popup_centered()
	name_edit.grab_focus()
