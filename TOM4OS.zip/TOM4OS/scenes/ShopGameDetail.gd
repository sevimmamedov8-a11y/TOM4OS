extends Control
## Карточка игры из «Магазина» (каталог Steam). Показывает официальные
## данные (обложка, описание, системные требования) и предлагает либо
## добавить игру в библиотеку TOM4OS (запуск дальше идёт через steam://,
## ничего не скачивается напрямую самим лаунчером), либо просто открыть
## страницу игры в Steam.

@onready var cover_rect: TextureRect = $CenterContainer/Panel/ScrollContainer/VBox/CoverRect
@onready var title_label: Label = $CenterContainer/Panel/ScrollContainer/VBox/TitleLabel
@onready var status_label: Label = $CenterContainer/Panel/ScrollContainer/VBox/StatusLabel
@onready var description_label: Label = $CenterContainer/Panel/ScrollContainer/VBox/DescriptionLabel
@onready var requirements_label: Label = $CenterContainer/Panel/ScrollContainer/VBox/RequirementsLabel
@onready var add_button: Button = $CenterContainer/Panel/ScrollContainer/VBox/ActionsRow/AddButton
@onready var controller_hints := $CenterContainer/Panel/ScrollContainer/VBox/HintsRow/ControllerHints

var _appid: int = 0
var _header_url: String = ""


func setup(appid: int) -> void:
	_appid = appid

	controller_hints.set_hints([
		{"kind": 0, "keyboard": "ENTER", "text": "Добавить в библиотеку"},
		{"kind": 1, "keyboard": "ESC", "text": "Назад"},
	])

	title_label.text = tr("Загрузка...")
	description_label.text = ""
	requirements_label.text = ""
	add_button.disabled = true

	var data: Dictionary = await SteamService.get_app_details(appid)
	if not is_instance_valid(self):
		return

	if data.is_empty():
		title_label.text = tr("Не удалось загрузить карточку игры")
		return

	title_label.text = String(data.get("name", ""))
	description_label.text = _strip_html(String(data.get("short_description", "")))

	var requirements: Dictionary = data.get("pc_requirements", {})
	var req_text := ""
	if requirements is Dictionary:
		req_text = _strip_html(String(requirements.get("minimum", "")))
	requirements_label.text = req_text if not req_text.is_empty() else tr("Не указаны")

	_header_url = String(data.get("header_image", SteamService.header_image_url(appid)))
	_load_cover()

	var already_owned := not GameLibrary.find_by_steam_appid(appid).is_empty()
	add_button.disabled = already_owned
	add_button.text = tr("Уже в библиотеке") if already_owned else tr("Добавить в библиотеку")

	add_button.grab_focus()


func _load_cover() -> void:
	var bytes: PackedByteArray = await SteamService.fetch_image_bytes(_header_url)
	if not is_instance_valid(self) or bytes.is_empty():
		return

	var img := Image.new()
	var err := img.load_jpg_from_buffer(bytes)
	if err != OK:
		err = img.load_png_from_buffer(bytes)
	if err != OK:
		return

	cover_rect.texture = ImageTexture.create_from_image(img)


## Steam-описания приходят в виде простого HTML - для консольного стиля
## интерфейса убираем теги, а переносы строк ставим по <br>/</p>/</li>.
func _strip_html(html: String) -> String:
	var text := html
	text = text.replace("<br>", "\n").replace("<br/>", "\n").replace("<br />", "\n")
	text = text.replace("</li>", "\n").replace("</p>", "\n\n")
	var tag_regex := RegEx.new()
	tag_regex.compile("<[^>]+>")
	text = tag_regex.sub(text, "", true)
	text = text.replace("&amp;", "&").replace("&nbsp;", " ")
	text = text.replace("&lt;", "<").replace("&gt;", ">").replace("&#39;", "'").replace("&quot;", "\"")
	return text.strip_edges()


func _on_add_pressed() -> void:
	add_button.disabled = true
	status_label.text = tr("Скачиваю обложку и добавляю в библиотеку...")

	var save_path := "%ssteam_%d.jpg" % [GameLibrary.get_covers_dir(), _appid]
	var ok: bool = await SteamService.download_image(_header_url, save_path)
	if not is_instance_valid(self):
		return

	GameLibrary.add_steam_game(_appid, title_label.text, save_path if ok else "")
	status_label.text = tr("Добавлено! Игра появится в библиотеке, запуск - через Steam.")
	add_button.text = tr("Уже в библиотеке")


func _on_open_steam_pressed() -> void:
	SteamService.open_store_page(_appid)


func _on_back_pressed() -> void:
	queue_free()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		queue_free()
		get_viewport().set_input_as_handled()
