extends Control
## Экран настроек: слева список разделов, справа их
## содержимое. Все изменения применяются сразу и сохраняются.

@onready var sidebar: VBoxContainer = $Dim/CenterContainer/Panel/HBox/Sidebar
@onready var exit_button: Button = $Dim/CenterContainer/Panel/HBox/Sidebar/ExitButton

@onready var page_appearance: Control = $Dim/CenterContainer/Panel/HBox/Pages/Appearance
@onready var page_library: Control = $Dim/CenterContainer/Panel/HBox/Pages/Library
@onready var page_steam: Control = $Dim/CenterContainer/Panel/HBox/Pages/Steam
@onready var page_users: Control = $Dim/CenterContainer/Panel/HBox/Pages/Users
@onready var page_achievements: Control = $Dim/CenterContainer/Panel/HBox/Pages/Achievements
@onready var page_backup: Control = $Dim/CenterContainer/Panel/HBox/Pages/Backup
@onready var page_about: Control = $Dim/CenterContainer/Panel/HBox/Pages/About

@onready var columns_spin: SpinBox = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/ColumnsRow/ColumnsSpin
@onready var animations_check: CheckButton = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/AnimationsCheck
@onready var vibration_check: CheckButton = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/VibrationCheck
@onready var screensaver_check: CheckButton = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/ScreensaverCheck
@onready var music_check: CheckButton = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/MusicCheck
@onready var music_volume_slider: HSlider = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/MusicVolumeRow/MusicVolumeSlider
@onready var background_option: OptionButton = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/BackgroundRow/BackgroundOption
@onready var language_option: OptionButton = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/LanguageRow/LanguageOption
@onready var accent_swatches: HBoxContainer = $Dim/CenterContainer/Panel/HBox/Pages/Appearance/VBox/AccentRow/AccentSwatches

@onready var auto_icon_check: CheckButton = $Dim/CenterContainer/Panel/HBox/Pages/Library/VBox/AutoIconCheck
@onready var api_key_edit: LineEdit = $Dim/CenterContainer/Panel/HBox/Pages/Library/VBox/ApiKeyEdit
@onready var refresh_covers_status: Label = $Dim/CenterContainer/Panel/HBox/Pages/Library/VBox/RefreshStatus

@onready var steam_api_key_edit: LineEdit = $Dim/CenterContainer/Panel/HBox/Pages/Steam/VBox/ApiKeyEdit
@onready var steam_profile_edit: LineEdit = $Dim/CenterContainer/Panel/HBox/Pages/Steam/VBox/ProfileEdit
@onready var steam_sync_button: Button = $Dim/CenterContainer/Panel/HBox/Pages/Steam/VBox/SyncButton
@onready var steam_sync_status: Label = $Dim/CenterContainer/Panel/HBox/Pages/Steam/VBox/SyncStatus

@onready var users_list: VBoxContainer = $Dim/CenterContainer/Panel/HBox/Pages/Users/VBox/UsersList
@onready var achievements_list: VBoxContainer = $Dim/CenterContainer/Panel/HBox/Pages/Achievements/VBox/ScrollContainer/AchievementsList
@onready var backup_status_label: Label = $Dim/CenterContainer/Panel/HBox/Pages/Backup/VBox/StatusLabel
@onready var backups_list: VBoxContainer = $Dim/CenterContainer/Panel/HBox/Pages/Backup/VBox/ScrollContainer/BackupsList
@onready var controller_hints := $Dim/CenterContainer/Panel/HBox/Sidebar/HintsRow/ControllerHints

const ACCENT_COLORS: Array[String] = [
	"#4f9dde", "#e5636b", "#59c48a", "#caa23e",
	"#9b6fd1", "#3fb8c9", "#e8935a", "#7fd1c9",
]
const CreateUserDialogScene := preload("res://scenes/CreateUserDialog.tscn")
const AvatarScene := preload("res://scenes/AvatarView.tscn")

var _sidebar_buttons: Array = []
var _all_pages: Array = []


func _ready() -> void:
	_sidebar_buttons = [
		sidebar.get_node("BtnAppearance"),
		sidebar.get_node("BtnLibrary"),
		sidebar.get_node("BtnSteam"),
		sidebar.get_node("BtnUsers"),
		sidebar.get_node("BtnAchievements"),
		sidebar.get_node("BtnBackup"),
		sidebar.get_node("BtnAbout"),
	]
	_all_pages = [page_appearance, page_library, page_steam, page_users, page_achievements, page_backup, page_about]

	controller_hints.set_hints([
		{"kind": 1, "keyboard": "ESC", "text": "Закрыть"},
	])

	# Кнопка выхода из лаунчера подсвечена приглушённым красным, чтобы
	# визуально отличаться от обычных кнопок навигации - это необратимое
	# действие (закрывает приложение), поэтому оно не должно теряться
	# среди остальных пунктов сайдбара.
	var exit_style := StyleBoxFlat.new()
	exit_style.bg_color = Color(0.45, 0.16, 0.16, 1.0)
	exit_style.corner_radius_top_left = 8
	exit_style.corner_radius_top_right = 8
	exit_style.corner_radius_bottom_left = 8
	exit_style.corner_radius_bottom_right = 8
	exit_style.content_margin_left = 10
	exit_style.content_margin_right = 10
	exit_style.content_margin_top = 6
	exit_style.content_margin_bottom = 6
	var exit_style_hover := exit_style.duplicate() as StyleBoxFlat
	exit_style_hover.bg_color = Color(0.6, 0.2, 0.2, 1.0)
	exit_button.add_theme_stylebox_override("normal", exit_style)
	exit_button.add_theme_stylebox_override("hover", exit_style_hover)
	exit_button.add_theme_stylebox_override("pressed", exit_style_hover)
	exit_button.add_theme_stylebox_override("focus", exit_style_hover)

	for i in _sidebar_buttons.size():
		var idx := i
		_sidebar_buttons[i].pressed.connect(func() -> void: _show_page(idx))

	# --- Внешний вид ---
	language_option.clear()
	for i in SettingsData.AVAILABLE_LANGUAGES.size():
		var lang: Dictionary = SettingsData.AVAILABLE_LANGUAGES[i]
		language_option.add_item(lang["name"], i)
	var current_lang := SettingsData.get_language()
	for i in SettingsData.AVAILABLE_LANGUAGES.size():
		if SettingsData.AVAILABLE_LANGUAGES[i]["code"] == current_lang:
			language_option.select(i)
			break
	language_option.item_selected.connect(_on_language_selected)

	columns_spin.value = SettingsData.get_columns()
	columns_spin.value_changed.connect(func(v: float) -> void: SettingsData.set_columns(int(v)))

	animations_check.button_pressed = SettingsData.get_animations_enabled()
	animations_check.toggled.connect(func(v: bool) -> void: SettingsData.set_animations_enabled(v))

	vibration_check.button_pressed = SettingsData.get_vibration_enabled()
	vibration_check.toggled.connect(func(v: bool) -> void: SettingsData.set_vibration_enabled(v))

	screensaver_check.button_pressed = SettingsData.get_screensaver_enabled()
	screensaver_check.toggled.connect(func(v: bool) -> void: SettingsData.set_screensaver_enabled(v))

	music_check.button_pressed = SettingsData.get_music_enabled()
	music_check.toggled.connect(func(v: bool) -> void: SettingsData.set_music_enabled(v))

	music_volume_slider.value = SettingsData.get_music_volume()
	music_volume_slider.value_changed.connect(func(v: float) -> void: SettingsData.set_music_volume(v))

	background_option.clear()
	background_option.add_item("Обложка последней игры (размыто)", 0)
	background_option.add_item("Градиент", 1)
	background_option.add_item("Сплошной цвет", 2)
	background_option.add_item("Живой фон (плавные цветные волны)", 3)
	var style := SettingsData.get_background_style()
	background_option.select(_style_to_index(style))
	background_option.item_selected.connect(_on_background_selected)

	for hex: String in ACCENT_COLORS:
		var b := Button.new()
		b.custom_minimum_size = Vector2(34, 34)
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(hex)
		sb.corner_radius_top_left = 8
		sb.corner_radius_top_right = 8
		sb.corner_radius_bottom_left = 8
		sb.corner_radius_bottom_right = 8
		b.add_theme_stylebox_override("normal", sb)
		b.add_theme_stylebox_override("hover", sb)
		b.add_theme_stylebox_override("pressed", sb)
		b.add_theme_stylebox_override("focus", sb)
		var hex_captured: String = hex
		b.pressed.connect(func() -> void: SettingsData.set_accent_color(hex_captured))
		accent_swatches.add_child(b)

	# --- Игры и обложки ---
	auto_icon_check.button_pressed = SettingsData.get_auto_icon_enabled()
	auto_icon_check.toggled.connect(func(v: bool) -> void: SettingsData.set_auto_icon_enabled(v))
	api_key_edit.text = SettingsData.get_steamgriddb_key()

	# --- Steam ---
	steam_api_key_edit.text = SettingsData.get_steam_api_key()
	steam_profile_edit.text = SettingsData.get_steam_profile()

	# --- Пользователи ---
	UserManager.users_changed.connect(_refresh_users_list)
	_refresh_users_list()

	# --- Достижения ---
	GameLibrary.achievement_unlocked.connect(func(_id: String, _title: String) -> void: _refresh_achievements_list())
	_refresh_achievements_list()

	# --- Резервные копии ---
	_refresh_backups_list()

	_show_page(0)


func _show_page(idx: int) -> void:
	for i in _all_pages.size():
		_all_pages[i].visible = (i == idx)
	for i in _sidebar_buttons.size():
		_sidebar_buttons[i].button_pressed = (i == idx)


func _style_to_index(style: String) -> int:
	match style:
		"gradient":
			return 1
		"solid":
			return 2
		"animated":
			return 3
		_:
			return 0


func _on_background_selected(idx: int) -> void:
	var style := "cover"
	match idx:
		1:
			style = "gradient"
		2:
			style = "solid"
		3:
			style = "animated"
	SettingsData.set_background_style(style)


func _on_language_selected(idx: int) -> void:
	if idx < 0 or idx >= SettingsData.AVAILABLE_LANGUAGES.size():
		return
	SettingsData.set_language(SettingsData.AVAILABLE_LANGUAGES[idx]["code"])


func _on_save_api_key_pressed() -> void:
	SettingsData.set_steamgriddb_key(api_key_edit.text)


func _on_steam_sync_pressed() -> void:
	var api_key := steam_api_key_edit.text.strip_edges()
	var profile := steam_profile_edit.text.strip_edges()

	if api_key.is_empty() or profile.is_empty():
		_set_steam_status(tr("Укажи API-ключ и профиль Steam."), false)
		return

	SettingsData.set_steam_api_key(api_key)
	SettingsData.set_steam_profile(profile)

	steam_sync_button.disabled = true
	_set_steam_status(tr("Определяю SteamID..."), null)

	var steamid := await SteamService.resolve_steam_id(profile, api_key)
	if steamid.is_empty():
		_set_steam_status(tr("Не удалось определить SteamID. Проверь API-ключ - для vanity-ссылок (steamcommunity.com/id/ИМЯ) он обязателен, для profiles/12345678901234567 не нужен, но всё равно должен быть заполнен."), false)
		steam_sync_button.disabled = false
		return

	_set_steam_status(tr("Получаю список игр..."), null)
	var owned_games := await SteamService.get_owned_games(steamid, api_key)
	if owned_games.is_empty():
		_set_steam_status(tr("Игры не найдены. В Steam: Настройки → Конфиденциальность → \"Сведения об игре\" должно быть \"Открыто для всех\" (не \"Только для друзей\")."), false)
		steam_sync_button.disabled = false
		return

	_set_steam_status(tr("Добавляю игры (%d) и скачиваю обложки...") % owned_games.size(), null)
	var added: int = await GameLibrary.sync_steam_games(owned_games)

	_set_steam_status(tr("Готово! Добавлено новых игр: %d") % added, true)
	steam_sync_button.disabled = false


## ok == true - успех (зелёный), false - ошибка (красный), null - просто
## промежуточный статус (нейтральный цвет). Раньше все статусы были одним
## тусклым белым текстом мелким шрифтом - ошибку было легко принять за
## "ничего не произошло".
func _set_steam_status(text: String, ok) -> void:
	steam_sync_status.text = text
	if ok == true:
		steam_sync_status.modulate = Color(0.55, 0.85, 0.6, 1)
	elif ok == false:
		steam_sync_status.modulate = Color(0.95, 0.55, 0.55, 1)
	else:
		steam_sync_status.modulate = Color(0.7, 0.75, 0.8, 1)


func _on_refresh_covers_pressed() -> void:
	if GameLibrary.games.is_empty():
		refresh_covers_status.text = "В библиотеке пока нет игр."
		return
	refresh_covers_status.text = "Обновляю обложки..."
	var updated := 0
	for g in GameLibrary.games:
		if SettingsData.get_auto_icon_enabled():
			if GameLibrary.auto_set_cover_from_exe(g["id"]):
				updated += 1
	refresh_covers_status.text = tr("Готово: обновлено %d из %d") % [updated, GameLibrary.games.size()]


func _refresh_users_list() -> void:
	for c in users_list.get_children():
		c.queue_free()
	for u in UserManager.users:
		users_list.add_child(_make_user_row(u))


func _make_user_row(u: Dictionary) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)

	var avatar := AvatarScene.instantiate()
	avatar.custom_minimum_size = Vector2(48, 48)
	row.add_child(avatar)
	avatar.setup(u.get("name", ""), u.get("accent_color", "#4f9dde"), u.get("avatar_path", ""))

	var name_label := Label.new()
	name_label.text = u.get("name", "")
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(name_label)

	if u["id"] == UserManager.current_user_id:
		var current_tag := Label.new()
		current_tag.text = "(текущий)"
		current_tag.modulate = Color(0.6, 0.9, 0.6, 1)
		row.add_child(current_tag)

	var user_id: String = u["id"]

	var edit_btn := Button.new()
	edit_btn.text = "Изменить"
	edit_btn.pressed.connect(func() -> void: _on_edit_user_pressed(user_id))
	row.add_child(edit_btn)

	if u["id"] != UserManager.current_user_id:
		var del_btn := Button.new()
		del_btn.text = "Удалить"
		del_btn.pressed.connect(func() -> void: UserManager.delete_user(user_id))
		row.add_child(del_btn)

	return row


func _on_edit_user_pressed(user_id: String) -> void:
	var dlg := CreateUserDialogScene.instantiate()
	add_child(dlg)
	dlg.setup_for_edit(user_id)
	dlg.popup_centered()


func _on_add_user_pressed() -> void:
	var dlg := CreateUserDialogScene.instantiate()
	add_child(dlg)
	dlg.popup_centered()


func _refresh_achievements_list() -> void:
	for c in achievements_list.get_children():
		c.queue_free()
	for def in GameLibrary.ACHIEVEMENTS:
		achievements_list.add_child(_make_achievement_row(def))


func _make_achievement_row(def: Dictionary) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)

	var unlocked: bool = GameLibrary.unlocked_achievements.has(def["id"])

	var icon := Label.new()
	icon.text = "🏆"
	icon.add_theme_font_size_override("font_size", 28)
	icon.modulate = Color(1, 0.85, 0.3, 1) if unlocked else Color(0.35, 0.37, 0.4, 1)
	row.add_child(icon)

	var vb := VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(vb)

	var title_lbl := Label.new()
	title_lbl.text = def.get("title", "")
	title_lbl.modulate = Color(1, 1, 1, 1) if unlocked else Color(0.6, 0.63, 0.67, 1)
	vb.add_child(title_lbl)

	var desc_lbl := Label.new()
	desc_lbl.text = def.get("desc", "")
	desc_lbl.add_theme_font_size_override("font_size", 12)
	desc_lbl.modulate = Color(0.7, 0.75, 0.8, 1)
	vb.add_child(desc_lbl)

	if unlocked:
		var tag := Label.new()
		tag.text = "Получено"
		tag.modulate = Color(0.5, 0.9, 0.55, 1)
		row.add_child(tag)

	return row


# ---------- Резервные копии ----------

func _on_create_backup_pressed() -> void:
	backup_status_label.text = "Создаю резервную копию..."
	backup_status_label.modulate = Color(0.7, 0.75, 0.8, 1)

	var path := BackupManager.create_backup()
	if path.is_empty():
		backup_status_label.text = "Не удалось создать резервную копию."
		backup_status_label.modulate = Color(0.9, 0.5, 0.5, 1)
		return

	backup_status_label.text = "Готово: %s" % path.get_file()
	backup_status_label.modulate = Color(0.55, 0.85, 0.6, 1)
	_refresh_backups_list()


func _on_open_backup_folder_pressed() -> void:
	OS.shell_open(BackupManager.get_backups_dir_absolute())


func _refresh_backups_list() -> void:
	for c in backups_list.get_children():
		c.queue_free()

	var backups := BackupManager.list_backups()
	if backups.is_empty():
		var empty_lbl := Label.new()
		empty_lbl.text = "Резервных копий пока нет - нажми «Создать резервную копию» выше."
		empty_lbl.modulate = Color(0.6, 0.65, 0.7, 1)
		backups_list.add_child(empty_lbl)
		return

	for backup in backups:
		backups_list.add_child(_make_backup_row(backup))


func _make_backup_row(backup: Dictionary) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)

	var name_lbl := Label.new()
	var dt := Time.get_datetime_dict_from_unix_time(int(backup.get("modified", 0)))
	name_lbl.text = "%04d-%02d-%02d %02d:%02d" % [dt["year"], dt["month"], dt["day"], dt["hour"], dt["minute"]]
	name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(name_lbl)

	var restore_btn := Button.new()
	restore_btn.text = "Восстановить"
	restore_btn.pressed.connect(func() -> void: _confirm_restore_backup(backup["path"]))
	row.add_child(restore_btn)

	var delete_btn := Button.new()
	delete_btn.text = "✕"
	delete_btn.custom_minimum_size = Vector2(40, 0)
	delete_btn.tooltip_text = "Удалить эту копию"
	delete_btn.pressed.connect(func() -> void:
		BackupManager.delete_backup(backup["path"])
		_refresh_backups_list()
	)
	row.add_child(delete_btn)

	return row


## Восстановление перезаписывает текущие профили, библиотеки и настройки
## данными из бэкапа - действие необратимое (то, что накопилось после
## создания копии, будет потеряно), поэтому явное подтверждение обязательно.
func _confirm_restore_backup(zip_path: String) -> void:
	var dialog := ConfirmationDialog.new()
	dialog.title = "Восстановить из резервной копии?"
	dialog.dialog_text = "Текущие профили, библиотеки игр и настройки будут заменены данными из копии. Лаунчер перезапустит текущий экран после восстановления."
	dialog.ok_button_text = "Восстановить"
	dialog.cancel_button_text = "Отмена"
	add_child(dialog)
	dialog.confirmed.connect(func() -> void:
		dialog.queue_free()
		_do_restore_backup(zip_path)
	)
	dialog.canceled.connect(func() -> void: dialog.queue_free())
	dialog.popup_centered()


func _do_restore_backup(zip_path: String) -> void:
	backup_status_label.text = "Восстанавливаю..."
	backup_status_label.modulate = Color(0.7, 0.75, 0.8, 1)

	var ok := BackupManager.restore_backup(zip_path)
	if not ok:
		backup_status_label.text = "Не удалось восстановить резервную копию."
		backup_status_label.modulate = Color(0.9, 0.5, 0.5, 1)
		return

	# Данные на диске изменились под ногами у всех автозагрузок - проще и
	# надёжнее всего перечитать список пользователей и текущую библиотеку
	# заново, чем пытаться точечно обновить состояние в памяти.
	UserManager.load_users()
	SettingsData.load_settings()
	SettingsData.apply_theme()
	SettingsData.apply_language()
	GameLibrary.reload_for_current_user()
	FriendsManager.reload_for_current_user()
	backup_status_label.text = "Восстановлено. Возвращаю к выбору профиля..."
	backup_status_label.modulate = Color(0.55, 0.85, 0.6, 1)

	queue_free()
	Transitions.fade_to_scene("res://scenes/ProfileSelect.tscn")


func _on_switch_user_pressed() -> void:
	queue_free()
	Transitions.fade_to_scene("res://scenes/ProfileSelect.tscn")


func _on_close_pressed() -> void:
	queue_free()


## Лаунчер запускается в полноэкранном режиме (см. project.godot,
## window/size/mode=3), поэтому без явной кнопки выхода единственный способ
## закрыть его - Alt+F4 или диспетчер задач. Показываем подтверждение,
## чтобы случайное нажатие на геймпаде не закрывало запущенные игры и не
## обрывало сохранение библиотеки на середине.
func _on_exit_pressed() -> void:
	var dialog := ConfirmationDialog.new()
	dialog.title = "Выход из TOM4OS"
	dialog.dialog_text = "Закрыть лаунчер? Запущенные через него игры не будут закрыты."
	dialog.ok_button_text = "Выйти"
	dialog.cancel_button_text = "Отмена"
	add_child(dialog)
	dialog.confirmed.connect(func() -> void:
		get_tree().quit()
	)
	dialog.canceled.connect(func() -> void:
		dialog.queue_free()
	)
	dialog.popup_centered()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		queue_free()
