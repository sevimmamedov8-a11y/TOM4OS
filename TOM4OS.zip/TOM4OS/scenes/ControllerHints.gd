extends HBoxContainer
## Переиспользуемая полоска подсказок контроллера. Разместить внизу любого
## экрана и вызвать set_hints() со списком подсказок. Каждая подсказка сама
## перерисовывается под текущий тип устройства ввода (Xbox/PlayStation/
## другой геймпад/клавиатура) через ButtonGlyph.

const ButtonGlyphScene := preload("res://scenes/ButtonGlyph.tscn")


## hints: Array подсказок вида {kind: ButtonGlyph.Kind, keyboard: "ENTER", text: "Играть"}
func set_hints(hints: Array) -> void:
	for c in get_children():
		c.queue_free()

	for h: Dictionary in hints:
		var item := HBoxContainer.new()
		item.add_theme_constant_override("separation", 6)

		var glyph := ButtonGlyphScene.instantiate()
		glyph.kind = h.get("kind", 0)
		glyph.keyboard_label = h.get("keyboard", "ENTER")
		item.add_child(glyph)

		var label := Label.new()
		label.text = h.get("text", "")
		label.modulate = Color(0.62, 0.67, 0.73, 1.0)
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		item.add_child(label)

		add_child(item)
