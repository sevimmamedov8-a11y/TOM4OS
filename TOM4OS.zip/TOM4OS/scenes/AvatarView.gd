extends Control
## Переиспользуемый виджет аватарки: если у пользователя выбрана своя
## картинка - показываем её, иначе рисуем цветной значок с первой буквой
## имени. Не использует @onready, чтобы setup() можно было безопасно
## вызывать сразу после instantiate(), не дожидаясь входа в дерево сцены.

const ROUNDNESS := 0.18  # доля от меньшей стороны - одинаковая скруглённость и у рамки, и у самой картинки

func setup(display_name: String, accent_hex: String, avatar_path: String = "") -> void:
	var bg: Panel = $Bg
	var img: TextureRect = $Bg/Img
	var initial_label: Label = $Bg/Initial

	var color := Color(0.31, 0.62, 0.87)
	if accent_hex.begins_with("#"):
		color = Color(accent_hex)

	var base_size: Vector2 = custom_minimum_size if custom_minimum_size.x > 0.0 else Vector2(96, 96)
	var px_radius: float = min(base_size.x, base_size.y) * ROUNDNESS

	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.corner_radius_top_left = int(px_radius)
	sb.corner_radius_top_right = int(px_radius)
	sb.corner_radius_bottom_left = int(px_radius)
	sb.corner_radius_bottom_right = int(px_radius)
	sb.shadow_color = Color(0, 0, 0, 0.35)
	sb.shadow_size = 6
	bg.add_theme_stylebox_override("panel", sb)

	var img_mat := img.material as ShaderMaterial
	if img_mat != null:
		img_mat.set_shader_parameter("radius", ROUNDNESS)

	if not avatar_path.is_empty() and FileAccess.file_exists(avatar_path):
		var image := Image.new()
		if image.load(avatar_path) == OK:
			img.texture = ImageTexture.create_from_image(image)
			img.visible = true
			initial_label.visible = false
			return

	img.visible = false
	initial_label.visible = true
	initial_label.text = display_name.substr(0, 1).to_upper() if display_name.length() > 0 else "?"
