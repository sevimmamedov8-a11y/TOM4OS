extends Control
## Загрузочный экран - показывается первым при старте лаунчера, до выбора
## пользователя (как на PlayStation). Проигрывает анимацию логотипа и
## полоску загрузки на фирменном анимированном фоне, затем плавно уходит
## на экран выбора профиля через Transitions. Можно пропустить нажатием
## любой клавиши / кнопки геймпада / клика мыши.

const BOOT_DURATION := 2.2
const SKIP_DURATION := 0.15

@onready var bg_animated: ColorRect = $BgAnimated
@onready var logo_label: Label = $CenterContainer/VBox/LogoLabel
@onready var hint_label: Label = $CenterContainer/VBox/HintLabel
@onready var loading_bar: ProgressBar = $CenterContainer/VBox/LoadingBar

var _elapsed: float = 0.0
var _finishing: bool = false


func _ready() -> void:
	SettingsData.apply_theme()

	var accent := Color(SettingsData.get_accent_color())
	var mat := bg_animated.material as ShaderMaterial
	if mat != null:
		mat.set_shader_parameter("accent_color", accent)
	loading_bar.modulate = accent

	if not SettingsData.get_animations_enabled():
		return

	logo_label.modulate.a = 0.0
	logo_label.scale = Vector2(0.85, 0.85)
	hint_label.modulate.a = 0.0
	call_deferred("_play_intro_animation")


func _play_intro_animation() -> void:
	logo_label.pivot_offset = logo_label.size / 2.0
	var tw := create_tween()
	tw.tween_property(logo_label, "modulate:a", 1.0, 0.5)
	tw.parallel().tween_property(logo_label, "scale", Vector2.ONE, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(hint_label, "modulate:a", 1.0, 0.4)


func _process(delta: float) -> void:
	if _finishing:
		return

	_elapsed += delta
	var duration := BOOT_DURATION if SettingsData.get_animations_enabled() else SKIP_DURATION
	loading_bar.value = clamp(_elapsed / duration, 0.0, 1.0) * 100.0

	if _elapsed >= duration:
		_finish_boot()


func _finish_boot() -> void:
	if _finishing:
		return
	_finishing = true
	set_process(false)
	Transitions.fade_to_scene("res://scenes/ProfileSelect.tscn")


func _unhandled_input(event: InputEvent) -> void:
	if _finishing:
		return
	var is_skip := (event is InputEventKey or event is InputEventJoypadButton or event is InputEventMouseButton) and event.is_pressed()
	if is_skip:
		get_viewport().set_input_as_handled()
		_finish_boot()
