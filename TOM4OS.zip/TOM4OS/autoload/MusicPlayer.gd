extends Node
## Autoload-синглтон. Проигрывает спокойную фоновую музыку по кругу
## на всех экранах лаунчера (Boot, ProfileSelect, Main, Settings...),
## поскольку сам является persist-синглтоном и не уничтожается при
## смене сцен. Громкость и вкл/выкл берутся из SettingsData и применяются
## сразу, как только меняются в Настройках. Пока запущена игра (см.
## GameLibrary.game_started/game_stopped), музыка плавно приглушается,
## чтобы не мешать звуку самой игры, и так же плавно возвращается после
## её закрытия.

const TRACK_PATH := "res://audio/background_loop.ogg"
const DUCK_DB := -80.0
const DUCK_FADE_SECONDS := 0.6

var _player: AudioStreamPlayer
var _ducked_for_game: bool = false


func _ready() -> void:
	_player = AudioStreamPlayer.new()
	_player.name = "MusicStreamPlayer"
	_player.bus = "Master"
	add_child(_player)

	var stream: AudioStream = load(TRACK_PATH)
	if stream == null:
		push_warning("MusicPlayer: не удалось загрузить %s" % TRACK_PATH)
		return

	# Включаем зацикливание прямо в коде, чтобы не зависеть от настроек
	# импорта ресурса в редакторе — так гарантированно работает всегда.
	if stream is AudioStreamOggVorbis:
		stream.loop = true
	elif stream is AudioStreamWAV:
		stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	elif stream is AudioStreamMP3:
		stream.loop = true

	_player.stream = stream
	_apply_volume()

	SettingsData.settings_changed.connect(_apply_volume)
	GameLibrary.game_started.connect(_on_game_started)
	GameLibrary.game_stopped.connect(_on_game_stopped)

	if SettingsData.get_music_enabled():
		_player.play()


func _apply_volume() -> void:
	if _player == null:
		return

	var enabled := SettingsData.get_music_enabled()
	if not enabled:
		if _player.playing:
			_player.stop()
		return

	# Пока приглушено из-за запущенной игры - не перебиваем дак громкостью
	# из настроек, она вернётся сама в _on_game_stopped().
	if _ducked_for_game:
		if not _player.playing:
			_player.play()
			_player.volume_db = DUCK_DB
		return

	var volume: float = SettingsData.get_music_volume()
	_player.volume_db = linear_to_db(clampf(volume, 0.001, 1.0))
	if not _player.playing:
		_player.play()


## Игры из Steam TOM4OS не отслеживает как процесс (Steam ими управляет
## сам) - для них никогда не придёт game_stopped, поэтому дак применяем
## только к играм, которые реально видны в GameLibrary.running_processes.
## Иначе музыка приглушилась бы навсегда после первого же запуска Steam-игры.
func _on_game_started(game_id: String) -> void:
	var tracked := false
	for info in GameLibrary.running_processes.values():
		if info["id"] == game_id:
			tracked = true
			break
	if not tracked:
		return

	_ducked_for_game = true
	if _player.playing:
		var tw := create_tween()
		tw.tween_property(_player, "volume_db", DUCK_DB, DUCK_FADE_SECONDS)


func _on_game_stopped(_game_id: String, _session_seconds: int) -> void:
	if not _ducked_for_game:
		return
	_ducked_for_game = false

	if not SettingsData.get_music_enabled():
		return

	var target_db: float = linear_to_db(clampf(SettingsData.get_music_volume(), 0.001, 1.0))
	if not _player.playing:
		_player.play()
		_player.volume_db = target_db
		return

	var tw := create_tween()
	tw.tween_property(_player, "volume_db", target_db, DUCK_FADE_SECONDS)

