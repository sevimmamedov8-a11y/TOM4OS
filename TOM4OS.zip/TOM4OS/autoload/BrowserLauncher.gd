extends Node
## Автозагружаемый синглтон для открытия сайтов во внешнем браузере.
##
## ВАЖНО: Godot из коробки не умеет рисовать веб-страницы внутри своего
## окна - для этого нужен сторонний рендер-движок (например Chromium через
## аддон gdcef), который тянет за собой отдельные бинарники под каждую
## платформу и подключается/собирается отдельно от самого проекта. Поэтому
## встроенный "браузер" здесь работает как быстрый доступ к сайтам: TOM4OS
## передаёт адрес уже установленному Firefox (если находит его) или
## браузеру по умолчанию, и тот открывается отдельным окном поверх
## лаунчера - примерно как ссылки в Steam Big Picture до появления у них
## собственного встроенного рендера.

const WINDOWS_FIREFOX_PATHS := [
	"C:/Program Files/Mozilla Firefox/firefox.exe",
	"C:/Program Files (x86)/Mozilla Firefox/firefox.exe",
]
const LINUX_FIREFOX_PATHS := [
	"/usr/bin/firefox",
	"/usr/bin/firefox-esr",
	"/snap/bin/firefox",
	"/var/lib/flatpak/exports/bin/org.mozilla.firefox",
]
const MACOS_FIREFOX_PATHS := [
	"/Applications/Firefox.app/Contents/MacOS/firefox",
]

var _cached_firefox_path: String = ""
var _firefox_lookup_done: bool = false


## Ищет установленный Firefox по стандартным путям для текущей ОС.
## Возвращает пустую строку, если не нашёл - тогда open_url() откроет
## системный браузер по умолчанию вместо него. Результат кэшируется, чтобы
## не сканировать диск при каждом клике по ссылке.
func find_firefox_path() -> String:
	if _firefox_lookup_done:
		return _cached_firefox_path
	_firefox_lookup_done = true

	var candidates: Array = []
	match OS.get_name():
		"Windows":
			candidates = WINDOWS_FIREFOX_PATHS
		"Linux":
			candidates = LINUX_FIREFOX_PATHS
		"macOS":
			candidates = MACOS_FIREFOX_PATHS

	for path in candidates:
		if FileAccess.file_exists(path):
			_cached_firefox_path = path
			return path

	# На Linux Firefox часто стоит через пакетный менеджер и есть в PATH,
	# даже если его нет по стандартным путям выше - проверяем через `which`.
	if OS.get_name() == "Linux":
		var output := []
		var exit_code := OS.execute("which", ["firefox"], output)
		if exit_code == 0 and not output.is_empty():
			var found: String = String(output[0]).strip_edges()
			if not found.is_empty() and FileAccess.file_exists(found):
				_cached_firefox_path = found
				return found

	return ""


## Приводит то, что ввёл пользователь, к нормальному адресу: похожее на
## домен/URL открывается как сайт, всё остальное считается поисковым
## запросом и уходит в поиск Google.
func normalize_input(raw: String) -> String:
	var text := raw.strip_edges()
	if text.is_empty():
		return ""

	if text.begins_with("http://") or text.begins_with("https://"):
		return text

	if not text.contains(" ") and text.contains("."):
		return "https://%s" % text

	return "https://www.google.com/search?q=%s" % text.uri_encode()


## Открывает адрес в Firefox, если он найден на этой машине, иначе - в
## браузере по умолчанию через OS.shell_open(). Возвращает словарь с
## результатом для показа статуса в интерфейсе: {ok, message, url}.
func open_url(raw_input: String) -> Dictionary:
	var url := normalize_input(raw_input)
	if url.is_empty():
		return {"ok": false, "message": "Введи адрес сайта или поисковый запрос."}

	var firefox_path := find_firefox_path()
	if not firefox_path.is_empty():
		var pid := OS.create_process(firefox_path, [url], false)
		if pid > 0:
			return {"ok": true, "message": "Открываю в Firefox: %s" % url, "url": url}
		push_warning("BrowserLauncher: не удалось запустить Firefox по пути '%s', пробую браузер по умолчанию" % firefox_path)

	var opened := OS.shell_open(url)
	if opened == OK:
		return {"ok": true, "message": "Открываю в браузере по умолчанию: %s" % url, "url": url}

	return {"ok": false, "message": "Не удалось открыть браузер. Проверь, что он установлен."}
