extends Node
## Autoload-синглтон для хранения общих настроек лаунчера: API-ключ
## SteamGridDB, число колонок в сетке, анимации, фон, акцентный цвет и т.д.

signal settings_changed

const SAVE_PATH := "user://settings.json"

var _data: Dictionary = {}


func _ready() -> void:
	load_settings()
	apply_language()


func load_settings() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		_data = {}
		return

	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		_data = {}
		return

	var text := file.get_as_text()
	file.close()

	var parsed = JSON.parse_string(text)
	_data = parsed if typeof(parsed) == TYPE_DICTIONARY else {}


func save_settings() -> void:
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		push_error("SettingsData: не удалось сохранить настройки")
		return
	file.store_string(JSON.stringify(_data, "\t"))
	file.close()


# ---------- SteamGridDB ----------

func get_steamgriddb_key() -> String:
	return _data.get("steamgriddb_key", "")


func set_steamgriddb_key(key: String) -> void:
	_data["steamgriddb_key"] = key
	save_settings()


# ---------- Steam (Web API ключ и профиль для синхронизации библиотеки) ----------

func get_steam_api_key() -> String:
	return _data.get("steam_api_key", "")


func set_steam_api_key(key: String) -> void:
	_data["steam_api_key"] = key
	save_settings()


func get_steam_profile() -> String:
	return _data.get("steam_profile", "")


func set_steam_profile(profile: String) -> void:
	_data["steam_profile"] = profile
	save_settings()


# ---------- Автообложка из иконки .exe ----------

func get_auto_icon_enabled() -> bool:
	return _data.get("auto_icon_enabled", true)


func set_auto_icon_enabled(v: bool) -> void:
	_data["auto_icon_enabled"] = v
	save_settings()
	settings_changed.emit()


# ---------- Внешний вид ----------

func get_columns() -> int:
	return int(_data.get("columns", 5))


func set_columns(v: int) -> void:
	_data["columns"] = v
	save_settings()
	settings_changed.emit()


func get_animations_enabled() -> bool:
	return _data.get("animations_enabled", true)


func set_animations_enabled(v: bool) -> void:
	_data["animations_enabled"] = v
	save_settings()
	settings_changed.emit()


func get_vibration_enabled() -> bool:
	return _data.get("vibration_enabled", true)


func set_vibration_enabled(v: bool) -> void:
	_data["vibration_enabled"] = v
	save_settings()
	settings_changed.emit()


## Экран отдыха (затемнение с часами) на главном экране после долгого
## бездействия - см. scenes/Main.gd. Включён по умолчанию, как на
## настоящих консолях.
func get_screensaver_enabled() -> bool:
	return _data.get("screensaver_enabled", true)


func set_screensaver_enabled(v: bool) -> void:
	_data["screensaver_enabled"] = v
	save_settings()
	settings_changed.emit()


## Короткий импульс вибрации геймпада (если подключён и включено в настройках).
## Используется при выборе профиля, наведении на игру и её запуске.
func vibrate(weak_magnitude: float, strong_magnitude: float, duration: float) -> void:
	if not get_vibration_enabled():
		return
	if Input.get_connected_joypads().is_empty():
		return
	Input.start_joy_vibration(0, weak_magnitude, strong_magnitude, duration)


# ---------- Фоновая музыка ----------

func get_music_enabled() -> bool:
	return _data.get("music_enabled", true)


func set_music_enabled(v: bool) -> void:
	_data["music_enabled"] = v
	save_settings()
	settings_changed.emit()


func get_music_volume() -> float:
	return float(_data.get("music_volume", 0.5))


func set_music_volume(v: float) -> void:
	_data["music_volume"] = clampf(v, 0.0, 1.0)
	save_settings()
	settings_changed.emit()


func get_background_style() -> String:
	# "cover" - размытая обложка последней игры, "gradient" - градиент,
	# "solid" - сплошной цвет (в тон акцентному цвету), "animated" - плавно
	# движущиеся цветные пятна - живой фон
	return _data.get("background_style", "cover")


func set_background_style(v: String) -> void:
	_data["background_style"] = v
	save_settings()
	settings_changed.emit()


func get_accent_color() -> String:
	return _data.get("accent_color", "#4f9dde")


func set_accent_color(v: String) -> void:
	_data["accent_color"] = v
	save_settings()
	apply_theme()
	settings_changed.emit()


# ---------- Язык интерфейса ----------

## Список языков, которые сейчас переведены (locale/translations.csv).
## Чтобы добавить новый язык - добавь колонку в CSV и строку сюда.
const AVAILABLE_LANGUAGES: Array[Dictionary] = [
	{"code": "ru", "name": "Русский"},
	{"code": "en", "name": "English"},
]

func get_language() -> String:
	return _data.get("language", "ru")


func set_language(code: String) -> void:
	_data["language"] = code
	save_settings()
	apply_language()
	settings_changed.emit()


## Применяет сохранённый язык интерфейса. Вызывается при старте (_ready)
## и при каждом изменении языка. TranslationServer.set_locale() сам
## посылает NOTIFICATION_TRANSLATION_CHANGED всем узлам в дереве, поэтому
## весь статический текст (Label/Button/тексты из .tscn) обновляется
## автоматически - вручную обновлять нужно только динамически собираемые
## строки (см. tr() в соответствующих местах кода).
func apply_language() -> void:
	TranslationServer.set_locale(get_language())


# ---------- Глобальная тема (акцентный цвет применяется ко всем экранам) ----------

func apply_theme() -> void:
	var accent := Color(get_accent_color())
	var theme := Theme.new()

	# ---------- Кнопки ----------
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0.145, 0.155, 0.185, 1.0)
	normal.set_corner_radius_all(14)
	normal.content_margin_left = 18
	normal.content_margin_right = 18
	normal.content_margin_top = 11
	normal.content_margin_bottom = 11
	normal.border_width_bottom = 1
	normal.border_color = Color(1, 1, 1, 0.05)
	normal.shadow_color = Color(0, 0, 0, 0.35)
	normal.shadow_size = 6
	normal.shadow_offset = Vector2(0, 3)

	var hover: StyleBoxFlat = normal.duplicate(true)
	hover.bg_color = accent.darkened(0.25)
	hover.shadow_color = accent.darkened(0.1)
	hover.shadow_color.a = 0.45
	hover.shadow_size = 10
	hover.shadow_offset = Vector2(0, 4)

	var pressed: StyleBoxFlat = normal.duplicate(true)
	pressed.bg_color = accent.darkened(0.5)
	pressed.shadow_size = 2
	pressed.shadow_offset = Vector2(0, 1)

	var focus: StyleBoxFlat = normal.duplicate(true)
	focus.bg_color = Color(0.17, 0.18, 0.21, 1.0)
	focus.border_color = accent
	focus.border_width_left = 3
	focus.border_width_right = 3
	focus.border_width_top = 3
	focus.border_width_bottom = 3
	focus.draw_center = true
	focus.shadow_color = accent
	focus.shadow_color.a = 0.5
	focus.shadow_size = 12

	var disabled: StyleBoxFlat = normal.duplicate(true)
	disabled.shadow_size = 0

	theme.set_stylebox("normal", "Button", normal)
	theme.set_stylebox("hover", "Button", hover)
	theme.set_stylebox("pressed", "Button", pressed)
	theme.set_stylebox("focus", "Button", focus)
	theme.set_stylebox("disabled", "Button", disabled)
	theme.set_color("font_hover_color", "Button", Color.WHITE)
	theme.set_color("font_pressed_color", "Button", Color.WHITE)
	theme.set_stylebox("focus", "CheckButton", focus)
	theme.set_stylebox("focus", "OptionButton", focus)

	# ---------- Панели (карточки, модальные окна) ----------
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color(0.11, 0.115, 0.14, 0.97)
	panel_style.set_corner_radius_all(22)
	panel_style.border_width_top = 1
	panel_style.border_width_bottom = 1
	panel_style.border_width_left = 1
	panel_style.border_width_right = 1
	panel_style.border_color = Color(1, 1, 1, 0.06)
	panel_style.shadow_color = Color(0, 0, 0, 0.5)
	panel_style.shadow_size = 24
	panel_style.shadow_offset = Vector2(0, 10)
	panel_style.content_margin_left = 26
	panel_style.content_margin_right = 26
	panel_style.content_margin_top = 24
	panel_style.content_margin_bottom = 24
	theme.set_stylebox("panel", "PanelContainer", panel_style)
	theme.set_stylebox("panel", "Panel", panel_style)

	# ---------- Слайдер громкости и прогресс-бар в акцентный цвет ----------
	var slider_grabber := StyleBoxFlat.new()
	slider_grabber.bg_color = accent
	slider_grabber.set_corner_radius_all(8)
	theme.set_stylebox("grabber_area", "HSlider", slider_grabber)
	theme.set_stylebox("grabber_area_highlight", "HSlider", slider_grabber)

	var progress_fill := StyleBoxFlat.new()
	progress_fill.bg_color = accent
	progress_fill.set_corner_radius_all(6)
	theme.set_stylebox("fill", "ProgressBar", progress_fill)

	var loop := Engine.get_main_loop()
	if loop is SceneTree:
		(loop as SceneTree).root.theme = theme
