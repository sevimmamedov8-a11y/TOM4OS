extends Node
## Autoload-синглтон. Определяет, каким устройством пользователь сейчас
## управляется - геймпадом Xbox, PlayStation, другим геймпадом или
## клавиатурой/мышью - чтобы подсказки кнопок внизу экрана (см.
## ControllerHints.gd) показывали правильные иконки. Переключается
## автоматически: нажал клавишу на клавиатуре - подсказки становятся
## "клавиатурными", тронул геймпад - возвращаются иконки контроллера.

signal type_changed(type: int)

enum Type { XBOX, PLAYSTATION, GENERIC, KEYBOARD }

const VENDOR_SONY := 0x054C
const VENDOR_MICROSOFT := 0x045E

var current_type: int = Type.KEYBOARD


func _ready() -> void:
	Input.joy_connection_changed.connect(_on_joy_connection_changed)
	_detect_from_connected_pads()


func _input(event: InputEvent) -> void:
	if event is InputEventJoypadButton or event is InputEventJoypadMotion:
		if current_type == Type.KEYBOARD:
			_detect_from_connected_pads()
	elif event is InputEventKey or event is InputEventMouseButton:
		_set_type(Type.KEYBOARD)


func _on_joy_connection_changed(_device: int, _connected: bool) -> void:
	_detect_from_connected_pads()


func _detect_from_connected_pads() -> void:
	var pads := Input.get_connected_joypads()
	if pads.is_empty():
		_set_type(Type.KEYBOARD)
		return

	var device: int = pads[0]
	var info := Input.get_joy_info(device)
	var vendor: int = int(info.get("vendor_id", 0))
	var pad_name := Input.get_joy_name(device).to_lower()

	if vendor == VENDOR_SONY or "playstation" in pad_name or "dualshock" in pad_name \
			or "dualsense" in pad_name or "wireless controller" in pad_name:
		_set_type(Type.PLAYSTATION)
	elif vendor == VENDOR_MICROSOFT or "xbox" in pad_name or "xinput" in pad_name:
		_set_type(Type.XBOX)
	else:
		_set_type(Type.GENERIC)


func _set_type(t: int) -> void:
	if t == current_type:
		return
	current_type = t
	type_changed.emit(t)
