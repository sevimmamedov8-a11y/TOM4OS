extends CanvasLayer
## Autoload-синглтон. Отвечает за плавные затемнения экрана при переходе
## между сценами (выбор профиля -> главный экран и обратно), чтобы не было
## резкой смены картинки.

var _rect: ColorRect


func _ready() -> void:
	layer = 200
	_rect = ColorRect.new()
	_rect.color = Color(0, 0, 0, 0)
	_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(_rect)


func fade_to_scene(path: String, duration: float = 0.3) -> void:
	_rect.mouse_filter = Control.MOUSE_FILTER_STOP

	if SettingsData.get_animations_enabled():
		var tw := create_tween()
		tw.tween_property(_rect, "color:a", 1.0, duration)
		await tw.finished
	else:
		_rect.color.a = 1.0

	get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	await get_tree().process_frame

	if SettingsData.get_animations_enabled():
		var tw2 := create_tween()
		tw2.tween_property(_rect, "color:a", 0.0, duration)
		await tw2.finished
	else:
		_rect.color.a = 0.0

	_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
