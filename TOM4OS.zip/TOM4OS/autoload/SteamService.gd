extends Node
## Автозагружаемый синглтон для работы с официальным Steam Web API и Store API.
##
## ВАЖНО: этот файл ничего не скачивает и не устанавливает сам - он только
## читает ПУБЛИЧНЫЕ данные (поиск по каталогу Steam, карточка игры) и, если
## пользователь сам ввёл свой API-ключ и профиль, список игр на его
## аккаунте. Сам запуск/установка игр из Steam всегда идёт через
## официальный протокол steam:// - его обрабатывает уже установленный у
## пользователя клиент Steam, TOM4OS в этот процесс не вмешивается.
##
## Официальная документация: https://steamcommunity.com/dev

const STORE_SEARCH_URL := "https://store.steampowered.com/api/storesearch/"
const APP_DETAILS_URL := "https://store.steampowered.com/api/appdetails"
const RESOLVE_VANITY_URL := "https://api.steampowered.com/ISteamUser/ResolveVanityURL/v1/"
const OWNED_GAMES_URL := "https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/"
const PLAYER_SUMMARIES_URL := "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/"


# ---------- Поиск по каталогу Steam (публичный эндпоинт, ключ не нужен) ----------

func search_catalog(query: String) -> Array:
	if query.strip_edges().is_empty():
		return []

	var url := "%s?term=%s&cc=ru&l=russian" % [STORE_SEARCH_URL, query.uri_encode()]
	var data = await _get_json(url)
	if data == null:
		return []
	return data.get("items", [])


# ---------- Подробная карточка игры (публичный эндпоинт, ключ не нужен) ----------

func get_app_details(appid: int) -> Dictionary:
	var url := "%s?appids=%d&l=russian&cc=ru" % [APP_DETAILS_URL, appid]
	var data = await _get_json(url)
	if data == null:
		return {}

	var entry: Dictionary = data.get(str(appid), {})
	if not entry.get("success", false):
		return {}
	return entry.get("data", {})


# ---------- Синхронизация личной библиотеки пользователя ----------

## Если пользователь ввёл ссылку вида steamcommunity.com/id/ИМЯ (vanity url)
## вместо 64-битного SteamID - разрешаем её через официальный API.
## Если это уже число (SteamID64) - возвращаем его как есть.
func resolve_steam_id(input: String, api_key: String) -> String:
	var cleaned := input.strip_edges()
	cleaned = cleaned.trim_suffix("/")
	if cleaned.contains("/"):
		cleaned = cleaned.get_slice("/", cleaned.get_slice_count("/") - 1)

	if cleaned.is_valid_int() and cleaned.length() >= 15:
		return cleaned

	if api_key.is_empty():
		return ""

	var url := "%s?key=%s&vanityurl=%s" % [RESOLVE_VANITY_URL, api_key.uri_encode(), cleaned.uri_encode()]
	var data = await _get_json(url)
	if data == null:
		return ""

	var response: Dictionary = data.get("response", {})
	if int(response.get("success", 0)) != 1:
		return ""
	return String(response.get("steamid", ""))


## Возвращает список купленных игр аккаунта:
## [{appid, name, playtime_forever, img_icon_url}, ...]
## Профиль должен быть публичным (Steam > Настройки конфиденциальности >
## "Сведения об игре" - "Открыто").
func get_owned_games(steamid: String, api_key: String) -> Array:
	if steamid.is_empty() or api_key.is_empty():
		return []

	var url := "%s?key=%s&steamid=%s&include_appinfo=1&include_played_free_games=1&format=json" % [
		OWNED_GAMES_URL, api_key.uri_encode(), steamid.uri_encode()
	]
	var data = await _get_json(url)
	if data == null:
		return []

	var response: Dictionary = data.get("response", {})
	return response.get("games", [])


## Публичные данные профиля(ей) по SteamID64 - имя, аватар, онлайн-статус
## (0 - офлайн, 1 - онлайн, 2 - занят, 3 - отошёл, 4 - на перерыве,
## 5/6 - ищет игру/трейд) и название игры, в которую сейчас играют
## (gameextrainfo), если профиль публичный. До 100 ID за один запрос -
## поэтому список друзей всегда опрашивается одним вызовом, а не по одному.
func get_player_summaries(steamids: Array, api_key: String) -> Array:
	if steamids.is_empty() or api_key.is_empty():
		return []

	var ids_param := ",".join(steamids)
	var url := "%s?key=%s&steamids=%s" % [PLAYER_SUMMARIES_URL, api_key.uri_encode(), ids_param.uri_encode()]
	var data = await _get_json(url)
	if data == null:
		return []

	var response: Dictionary = data.get("response", {})
	return response.get("players", [])


# ---------- Вспомогательные функции ----------

func _get_json(url: String):
	var req := HTTPRequest.new()
	add_child(req)
	var err := req.request(url)
	if err != OK:
		req.queue_free()
		push_error("Steam: не удалось выполнить запрос к %s" % url)
		return null

	var result = await req.request_completed
	req.queue_free()

	var code: int = result[1]
	var body: PackedByteArray = result[3]
	if code != 200:
		push_error("Steam: сервер ответил кодом %d (%s)" % [code, url])
		return null

	return JSON.parse_string(body.get_string_from_utf8())


## Скачивает картинку (обложку/скриншот) по прямой ссылке с официального
## CDN Steam и сохраняет её локально - используется как обычная загрузка
## изображения, а не файла игры.
## Скачивает картинку в память (без сохранения на диск) - удобно для
## превью в каталоге поиска, где сохранять каждую миниатюру не нужно.
func fetch_image_bytes(url: String) -> PackedByteArray:
	if url.is_empty():
		return PackedByteArray()

	var req := HTTPRequest.new()
	add_child(req)
	var err := req.request(url)
	if err != OK:
		req.queue_free()
		return PackedByteArray()

	var result = await req.request_completed
	req.queue_free()

	var code: int = result[1]
	if code != 200:
		return PackedByteArray()
	return result[3]


func download_image(url: String, save_path: String) -> bool:
	if url.is_empty():
		return false

	var req := HTTPRequest.new()
	add_child(req)
	var err := req.request(url)
	if err != OK:
		req.queue_free()
		return false

	var result = await req.request_completed
	req.queue_free()

	var code: int = result[1]
	var bytes: PackedByteArray = result[3]
	if code != 200:
		push_error("Steam: не удалось скачать изображение, код %d" % code)
		return false

	var file := FileAccess.open(save_path, FileAccess.WRITE)
	if file == null:
		return false
	file.store_buffer(bytes)
	file.close()
	return true


## Прямая ссылка на обложку (header image) игры в official Steam CDN.
func header_image_url(appid: int) -> String:
	return "https://cdn.akamai.steamstatic.com/steam/apps/%d/header.jpg" % appid


## Открывает запуск/установку игры через официальный протокол steam:// -
## дальше всем занимается уже установленный у пользователя клиент Steam.
## TOM4OS ничего не скачивает и не устанавливает самостоятельно.
func launch_via_steam(appid: int) -> void:
	OS.shell_open("steam://run/%d" % appid)


## Открывает страницу игры в магазине Steam в браузере/клиенте.
func open_store_page(appid: int) -> void:
	OS.shell_open("steam://store/%d" % appid)
