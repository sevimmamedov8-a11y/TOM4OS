extends Node
## Автозагружаемый синглтон резервного копирования. Складывает всё
## содержимое user:// (профили, библиотеки игр, обложки, достижения,
## настройки, закладки браузера) в один .zip и умеет разворачивать такой
## архив обратно. Бэкапы лежат в user://backups/ - это реальная папка на
## диске, путь к ней можно узнать через get_backups_dir_absolute().
##
## Специально не использует внешних библиотек - ZIPPacker/ZIPReader есть
## в Godot из коробки.

const BACKUPS_DIR := "user://backups"

## Не кладём саму папку с бэкапами внутрь нового бэкапа - иначе каждый
## следующий архив включал бы в себя все предыдущие и раздувался бы
## по экспоненте.
const EXCLUDED_TOP_LEVEL := ["backups"]


func _ensure_backups_dir() -> void:
	if not DirAccess.dir_exists_absolute(BACKUPS_DIR):
		DirAccess.make_dir_recursive_absolute(BACKUPS_DIR)


## Реальный путь к папке с бэкапами на диске (для кнопки "Открыть папку").
func get_backups_dir_absolute() -> String:
	_ensure_backups_dir()
	return ProjectSettings.globalize_path(BACKUPS_DIR)


## Складывает всё содержимое user:// (кроме папки backups) в новый .zip.
## Возвращает путь к созданному файлу или пустую строку при ошибке.
func create_backup() -> String:
	_ensure_backups_dir()

	var stamp := Time.get_datetime_string_from_system().replace(":", "-").replace("T", "_")
	var zip_path := "%s/TOM4OS_backup_%s.zip" % [BACKUPS_DIR, stamp]

	var zip := ZIPPacker.new()
	var err := zip.open(zip_path)
	if err != OK:
		push_error("BackupManager: не удалось создать архив (код %d)" % err)
		return ""

	_zip_add_dir_recursive(zip, "user://", "")
	zip.close()
	return zip_path


func _zip_add_dir_recursive(zip: ZIPPacker, source_dir: String, zip_prefix: String) -> void:
	var dir := DirAccess.open(source_dir)
	if dir == null:
		return

	dir.list_dir_begin()
	var entry := dir.get_next()
	while entry != "":
		if entry == "." or entry == "..":
			entry = dir.get_next()
			continue
		if zip_prefix.is_empty() and EXCLUDED_TOP_LEVEL.has(entry):
			entry = dir.get_next()
			continue

		var full_source := "%s%s" % [source_dir, entry]
		var zip_entry_name := "%s%s" % [zip_prefix, entry]

		if dir.current_is_dir():
			_zip_add_dir_recursive(zip, "%s/" % full_source, "%s/" % zip_entry_name)
		else:
			var file := FileAccess.open(full_source, FileAccess.READ)
			if file != null:
				zip.start_file(zip_entry_name)
				zip.write_file(file.get_buffer(file.get_length()))
				zip.close_file()
				file.close()

		entry = dir.get_next()
	dir.list_dir_end()


## Список существующих бэкапов, самые новые - первыми.
func list_backups() -> Array:
	_ensure_backups_dir()
	var result: Array = []

	var dir := DirAccess.open(BACKUPS_DIR)
	if dir == null:
		return result

	dir.list_dir_begin()
	var entry := dir.get_next()
	while entry != "":
		if not dir.current_is_dir() and entry.ends_with(".zip"):
			var full_path := "%s/%s" % [BACKUPS_DIR, entry]
			result.append({
				"path": full_path,
				"name": entry,
				"modified": FileAccess.get_modified_time(full_path),
			})
		entry = dir.get_next()
	dir.list_dir_end()

	result.sort_custom(func(a, b): return a["modified"] > b["modified"])
	return result


func delete_backup(path: String) -> void:
	DirAccess.remove_absolute(path)


## Разворачивает архив обратно поверх текущих данных user:// - существующие
## файлы с теми же именами перезаписываются, остальные не трогаются.
## Вызывающая сторона (Settings.gd) обязана сначала спросить подтверждение
## у пользователя - это необратимая перезапись текущих данных.
func restore_backup(zip_path: String) -> bool:
	var reader := ZIPReader.new()
	var err := reader.open(zip_path)
	if err != OK:
		push_error("BackupManager: не удалось открыть архив для восстановления (код %d)" % err)
		return false

	for rel_path in reader.get_files():
		if rel_path.ends_with("/"):
			DirAccess.make_dir_recursive_absolute("user://%s" % rel_path)
			continue

		var data := reader.read_file(rel_path)
		var dest_path := "user://%s" % rel_path
		var dest_dir := dest_path.get_base_dir()
		if not dest_dir.is_empty() and not DirAccess.dir_exists_absolute(dest_dir):
			DirAccess.make_dir_recursive_absolute(dest_dir)

		var out := FileAccess.open(dest_path, FileAccess.WRITE)
		if out == null:
			continue
		out.store_buffer(data)
		out.close()

	reader.close()
	return true
