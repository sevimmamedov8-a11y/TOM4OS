extends Node
## Autoload-синглтон. Хранит список пользователей (профилей) лаунчера,
## их аватарки и текущего выбранного пользователя. У каждого пользователя
## своя отдельная библиотека игр (см. GameLibrary.reload_for_current_user()).

signal users_changed
signal user_selected(user_id: String)

const USERS_FILE := "user://users.json"

const ACCENT_COLORS: Array[String] = [
	"#4f9dde", "#e5636b", "#59c48a", "#caa23e",
	"#9b6fd1", "#3fb8c9", "#e8935a", "#7fd1c9",
]

var users: Array = []          # Array[Dictionary] {id, name, avatar_path, accent_color}
var current_user_id: String = ""


func _ready() -> void:
	load_users()


func load_users() -> void:
	users = []
	current_user_id = ""

	if not FileAccess.file_exists(USERS_FILE):
		users_changed.emit()
		return

	var file := FileAccess.open(USERS_FILE, FileAccess.READ)
	if file == null:
		users_changed.emit()
		return

	var text := file.get_as_text()
	file.close()

	var parsed = JSON.parse_string(text)
	if typeof(parsed) == TYPE_DICTIONARY:
		users = parsed.get("users", [])
		current_user_id = parsed.get("last_user_id", "")

	users_changed.emit()


func save_users() -> void:
	var data := {"users": users, "last_user_id": current_user_id}
	var file := FileAccess.open(USERS_FILE, FileAccess.WRITE)
	if file == null:
		push_error("UserManager: не удалось сохранить пользователей")
		return
	file.store_string(JSON.stringify(data, "\t"))
	file.close()


func _generate_id() -> String:
	return str(int(Time.get_unix_time_from_system())) + "_" + str(randi() % 1000000)


# ---------- CRUD профилей ----------

func create_user(display_name: String, avatar_path: String = "", accent_color: String = "") -> Dictionary:
	var color := accent_color
	if color.is_empty():
		color = ACCENT_COLORS[randi() % ACCENT_COLORS.size()]

	var final_name := display_name.strip_edges()
	if final_name.is_empty():
		final_name = "Игрок"

	var entry := {
		"id": _generate_id(),
		"name": final_name,
		"avatar_path": avatar_path,
		"accent_color": color,
	}
	users.append(entry)
	save_users()
	_ensure_user_dirs(entry["id"])
	users_changed.emit()
	return entry


func rename_user(user_id: String, new_name: String) -> void:
	var u := get_user(user_id)
	if not u.is_empty() and not new_name.strip_edges().is_empty():
		u["name"] = new_name.strip_edges()
		save_users()
		users_changed.emit()


func set_user_avatar(user_id: String, avatar_path: String) -> void:
	var u := get_user(user_id)
	if not u.is_empty():
		u["avatar_path"] = avatar_path
		save_users()
		users_changed.emit()


func set_user_accent(user_id: String, accent_color: String) -> void:
	var u := get_user(user_id)
	if not u.is_empty():
		u["accent_color"] = accent_color
		save_users()
		users_changed.emit()


func delete_user(user_id: String) -> void:
	for i in users.size():
		if users[i]["id"] == user_id:
			users.remove_at(i)
			break
	if current_user_id == user_id:
		current_user_id = ""
	save_users()
	_delete_user_data(user_id)
	users_changed.emit()


func get_user(user_id: String) -> Dictionary:
	for u in users:
		if u["id"] == user_id:
			return u
	return {}


func select_user(user_id: String) -> void:
	current_user_id = user_id
	save_users()
	user_selected.emit(user_id)


# ---------- Папки данных пользователя ----------

func _ensure_user_dirs(user_id: String) -> void:
	var dir := "user://users/%s/covers/" % user_id
	if not DirAccess.dir_exists_absolute(dir):
		DirAccess.make_dir_recursive_absolute(dir)


func _delete_user_data(user_id: String) -> void:
	_remove_dir_recursive("user://users/%s" % user_id)


func _remove_dir_recursive(path: String) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	dir.list_dir_begin()
	var entry_name := dir.get_next()
	while entry_name != "":
		if entry_name != "." and entry_name != "..":
			var full := path + "/" + entry_name
			if dir.current_is_dir():
				_remove_dir_recursive(full)
			else:
				DirAccess.remove_absolute(full)
		entry_name = dir.get_next()
	dir.list_dir_end()
	DirAccess.remove_absolute(path)
