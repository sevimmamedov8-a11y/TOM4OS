extends Node
## Autoload-синглтон списка друзей ТЕКУЩЕГО профиля (как GameLibrary -
## своя папка на каждого пользователя, см. reload_for_current_user()).
##
## Друзья хранятся локально (ник/заметка) и, если в Настройках → Steam
## указан свой API-ключ, дополнительно обогащаются РЕАЛЬНЫМ статусом из
## Steam (онлайн/офлайн/в какой игре) - см. SteamService.get_player_summaries().
## Это честно работает между разными компьютерами, потому что данные идут
## с серверов Steam, а не от самого TOM4OS - у него нет и не может быть
## своего сервера для настоящей "внутренней" сети друзей.

signal friends_changed
signal statuses_updated

const REFRESH_INTERVAL_SECONDS := 60.0

var friends: Array = []  # Array[Dictionary] {id, display_name, steam_input, note, steamid64}
var statuses: Dictionary = {}  # steamid64(String) -> player summary Dictionary из Steam API

var _save_path: String = ""
var _refresh_timer: Timer


func _ready() -> void:
	_refresh_timer = Timer.new()
	_refresh_timer.wait_time = REFRESH_INTERVAL_SECONDS
	_refresh_timer.autostart = false
	_refresh_timer.timeout.connect(func() -> void: refresh_statuses())
	add_child(_refresh_timer)


func reload_for_current_user() -> void:
	var uid := UserManager.current_user_id
	if uid.is_empty():
		_save_path = "user://friends.json"
	else:
		_save_path = "user://users/%s/friends.json" % uid

	statuses.clear()
	_load_friends()
	refresh_statuses()
	_refresh_timer.start()


func _generate_id() -> String:
	return str(int(Time.get_unix_time_from_system())) + "_" + str(randi() % 1000000)


func _load_friends() -> void:
	friends.clear()
	if _save_path.is_empty() or not FileAccess.file_exists(_save_path):
		friends_changed.emit()
		return

	var file := FileAccess.open(_save_path, FileAccess.READ)
	if file == null:
		friends_changed.emit()
		return

	var text := file.get_as_text()
	file.close()

	var parsed = JSON.parse_string(text)
	if typeof(parsed) == TYPE_DICTIONARY and parsed.has("friends"):
		friends = parsed["friends"]

	friends_changed.emit()


func _save_friends() -> void:
	if _save_path.is_empty():
		return
	var file := FileAccess.open(_save_path, FileAccess.WRITE)
	if file == null:
		push_error("FriendsManager: не удалось сохранить список друзей")
		return
	file.store_string(JSON.stringify({"friends": friends}, "\t"))
	file.close()


## display_name - как друг будет подписан в списке. steam_input -
## необязательно: SteamID64, ссылка на профиль или vanity-имя
## (steamcommunity.com/id/ИМЯ) - если указано и есть API-ключ, статус
## друга будет подтягиваться из Steam. note - свободная заметка ("брат",
## "играем по вторникам" и т.п.).
func add_friend(display_name: String, steam_input: String = "", note: String = "") -> Dictionary:
	var entry := {
		"id": _generate_id(),
		"display_name": display_name.strip_edges(),
		"steam_input": steam_input.strip_edges(),
		"note": note.strip_edges(),
		"steamid64": "",
	}
	friends.append(entry)
	_save_friends()
	friends_changed.emit()
	refresh_statuses()
	return entry


func remove_friend(friend_id: String) -> void:
	for i in friends.size():
		if friends[i]["id"] == friend_id:
			friends.remove_at(i)
			break
	_save_friends()
	friends_changed.emit()


func update_friend(friend_id: String, display_name: String, steam_input: String, note: String) -> void:
	for f in friends:
		if f["id"] == friend_id:
			f["display_name"] = display_name.strip_edges()
			f["steam_input"] = steam_input.strip_edges()
			f["note"] = note.strip_edges()
			f["steamid64"] = ""  # переразрешим по новому steam_input при следующем refresh
			break
	_save_friends()
	friends_changed.emit()
	refresh_statuses()


## Разрешает steam_input у всех друзей в SteamID64 (если ещё не разрешён)
## и одним запросом опрашивает статус у Steam. Если API-ключ не задан в
## Настройках → Steam - просто ничего не делает (список остаётся, но без
## живого статуса, как обычная записная книжка).
func refresh_statuses() -> void:
	var api_key := SettingsData.get_steam_api_key()
	if api_key.is_empty():
		return

	var ids_to_query: Array = []
	for f in friends:
		if String(f.get("steam_input", "")).is_empty():
			continue
		if String(f.get("steamid64", "")).is_empty():
			var resolved: String = await SteamService.resolve_steam_id(f["steam_input"], api_key)
			f["steamid64"] = resolved
		if not String(f.get("steamid64", "")).is_empty():
			ids_to_query.append(f["steamid64"])

	_save_friends()

	if ids_to_query.is_empty():
		statuses_updated.emit()
		return

	var players := await SteamService.get_player_summaries(ids_to_query, api_key)
	statuses.clear()
	for p in players:
		statuses[String(p.get("steamid", ""))] = p

	statuses_updated.emit()


## Готовый для UI статус одного друга: {online, text, color, game}.
func get_display_status(friend: Dictionary) -> Dictionary:
	var steamid: String = friend.get("steamid64", "")
	if steamid.is_empty() or not statuses.has(steamid):
		if String(friend.get("steam_input", "")).is_empty():
			return {"online": false, "text": "Локальный контакт", "color": Color(0.6, 0.65, 0.7, 1), "game": ""}
		return {"online": false, "text": "Статус недоступен", "color": Color(0.55, 0.58, 0.62, 1), "game": ""}

	var p: Dictionary = statuses[steamid]
	var game := String(p.get("gameextrainfo", ""))
	if not game.is_empty():
		return {"online": true, "text": "В игре: %s" % game, "color": Color(0.4, 0.85, 0.5, 1), "game": game}

	var state := int(p.get("personastate", 0))
	match state:
		0:
			return {"online": false, "text": "Не в сети", "color": Color(0.55, 0.58, 0.62, 1), "game": ""}
		1:
			return {"online": true, "text": "В сети", "color": Color(0.4, 0.7, 0.95, 1), "game": ""}
		3:
			return {"online": true, "text": "Отошёл", "color": Color(0.85, 0.7, 0.35, 1), "game": ""}
		4:
			return {"online": true, "text": "На перерыве", "color": Color(0.85, 0.7, 0.35, 1), "game": ""}
		_:
			return {"online": true, "text": "В сети", "color": Color(0.4, 0.7, 0.95, 1), "game": ""}
